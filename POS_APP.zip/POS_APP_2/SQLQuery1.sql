-- Table: Users
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username VARCHAR(100) NOT NULL,
    Password VARCHAR(100) NOT NULL,
    Role VARCHAR(50) NOT NULL,
 IsApproved BIT NOT NULL DEFAULT 0
);

CREATE TABLE MenuItems (
	MenuItemID INT PRIMARY KEY IDENTITY(1,1),
	ItemName VARCHAR(100),
	Category VARCHAR(100),
	Unit VARCHAR(50),
	Quantity INT,
	Price DECIMAL(10, 2),
	Vendor VARCHAR(100),
	DateReceived DATE
);

-- Table: Orders
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    OrderDate DATETIME DEFAULT GETDATE(),
    TotalAmount DECIMAL(10,2),
PaymentMethod NVARCHAR(50) NOT NULL DEFAULT 'Cash',
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
Discount DECIMAL(18,2) NOT NULL DEFAULT 0,
    FinalAmount DECIMAL(18,2) NOT NULL Default 0
);

-- Table: OrderDetails
CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT FOREIGN KEY REFERENCES Orders(OrderID),
    MenuItemID INT FOREIGN KEY REFERENCES MenuItems(MenuItemID),
    Quantity INT,
    UnitPrice DECIMAL(10,2)
);

CREATE TABLE ItemCategories (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE ExpenseCategory (
    Id INT PRIMARY KEY IDENTITY(1,1),
    CategoryName VARCHAR(100) NOT NULL
);

CREATE TABLE Expense (
    ExpenseID INT PRIMARY KEY IDENTITY(1,1),
    Category NVARCHAR(100),
    Remarks NVARCHAR(255),
    ExpenseDate DATE,
    Amount DECIMAL(10,2)
);

CREATE TABLE Stock (
    StockID INT PRIMARY KEY IDENTITY(1,1),
    MenuItemID INT NOT NULL,
    QuantityAdded INT NOT NULL,
    DateAdded DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (MenuItemID) REFERENCES MenuItems(MenuItemID)
);

CREATE TABLE StockTransactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    MenuItemID INT FOREIGN KEY REFERENCES MenuItems(MenuItemID),
    ChangeInQuantity INT NOT NULL,               -- (+/-)
    TransactionDate DATETIME DEFAULT GETDATE(),
    Notes VARCHAR(255)
);

CREATE TABLE StockReconciliationReport (
    Id INT PRIMARY KEY IDENTITY(1,1),
    MenuItemID INT FOREIGN KEY REFERENCES MenuItems(MenuItemID),
    OpeningStock INT NOT NULL,
    Purchases INT NOT NULL,
    Sales INT NOT NULL,
    PurchaseReturns INT DEFAULT 0,       -- Return to vendor (reduce stock)
    SalesReturns INT DEFAULT 0,          -- Return from customer (add to stock)
    DamagedOrExpired INT DEFAULT 0,
    ManualAdjustment INT DEFAULT 0,
    CalculatedClosing INT NOT NULL,      -- System Qty
    PhysicalStock INT NOT NULL,          -- Counted manually
    Difference INT NOT NULL,             -- Variance = Physical - System
    Date DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    CONSTRAINT UQ_StockReconciliation_UniqueDatePerItem UNIQUE (MenuItemID, Date)
);

CREATE TABLE ReturnToVendor (
    ReturnID INT PRIMARY KEY IDENTITY(1,1),
    MenuItemID INT FOREIGN KEY REFERENCES MenuItems(MenuItemID),
    ReturnDate DATETIME DEFAULT GETDATE(),
    QuantityReturned INT NOT NULL,
    Reason VARCHAR(100),
    Notes VARCHAR(255)
);

CREATE TABLE ReturnTransactions (
    ReturnID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    MenuItemID INT NOT NULL,
    ReturnQuantity INT NOT NULL,
    ReturnDate DATETIME DEFAULT GETDATE(),
    UnitPrice DECIMAL(10,2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (MenuItemID) REFERENCES MenuItems(MenuItemID)
);

INSERT INTO Users (Username, Password, Role, IsApproved)

VALUES ('ah', 'ah', 'Admin', 1);
ALTER TABLE MenuItems DROP CONSTRAINT UQ__MenuItem__3ECC0FEA91E51396;

ALTER TABLE MenuItems DROP COLUMN ItemCode;




