﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS_APP.Models
{
    class SalesReport
    {
        public string ItemName { get; set; }
        public int QuantitySold { get; set; }
        public decimal OriginalAmount { get; set; }  
        public decimal DiscountAmount { get; set; }   
        public decimal FinalAmount { get; set; }      
        public string PaymentMethod { get; set; }
        public DateTime Date { get; set; }
        public string SoldBy { get; set; }

        public decimal TotalAmount => FinalAmount;

        public SalesReport(string itemName, int quantitySold, decimal originalAmount,
                         decimal discountAmount, decimal finalAmount, DateTime date,
                         string soldBy, string payment)
        {
            ItemName = itemName;
            QuantitySold = quantitySold;
            OriginalAmount = originalAmount;
            DiscountAmount = discountAmount;
            FinalAmount = finalAmount;
            Date = date;
            SoldBy = soldBy;
            PaymentMethod = payment;
        }

        public SalesReport() { }
    }
}