﻿public class ReceivedStockItem
{
	public string? ItemCode { get; set; }  // Added property
	public int MenuItemID { get; set; }
	public string? Vendor { get; set; }
	public string? Category { get; set; }
	public string? Item { get; set; }
	public int Quantity { get; set; }
	public string? Unit { get; set; }
	public decimal Price { get; set; }
	public DateTime Date { get; set; }
}
