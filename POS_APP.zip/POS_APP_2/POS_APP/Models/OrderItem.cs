﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace POS_APP.Models
{
   public class OrderItem : INotifyPropertyChanged
    {
        private int _quantity;
        private decimal _unitPrice;

        public int MenuItemID { get; set; }
        public int SrNo { get; set; }
        public string? Category { get; set; }
        public string? ItemName { get; set; }

        public int Quantity
        {
            get => _quantity;
            set
            {
                _quantity = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Total)); 
            }
        }

        public decimal UnitPrice
        {
            get => _unitPrice;
            set
            {
                _unitPrice = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Total)); 
            }
        }

        public decimal Total => UnitPrice * Quantity;

        public event PropertyChangedEventHandler? PropertyChanged;

		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}