﻿using POS_APP.DL;
using POS_APP.Models;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace POS_APP.UI
{
	public partial class ReturnToVendorForm : Window
	{
		public ReturnToVendorForm()
		{
			InitializeComponent();
			LoadItemsFromStock();
		}

		private void LoadItemsFromStock()
		{
			try
			{
				var itemsInStock = MenuItemDL.GetAllItems()
					.Where(item => item.Quantity > 0)
					.Select(item => new
					{
						item.MenuItemID,
						ItemName = item.Item // Ensure you're binding to ItemName from DB
					})
					.ToList();

				cmbItems.ItemsSource = itemsInStock;
				cmbItems.DisplayMemberPath = "ItemName";
				cmbItems.SelectedValuePath = "MenuItemID";
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading items: {ex.Message}", "Load Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void btnSubmit_Click(object sender, RoutedEventArgs e)
		{
			if (cmbItems.SelectedValue == null || string.IsNullOrWhiteSpace(txtQuantity.Text) || cmbReason.SelectedItem == null)
			{
				MessageBox.Show("Please fill all required fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			if (!int.TryParse(txtQuantity.Text.Trim(), out int returnQty) || returnQty <= 0)
			{
				MessageBox.Show("Invalid return quantity.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			int itemId = (int)cmbItems.SelectedValue;
			string reason = (cmbReason.SelectedItem as ComboBoxItem)?.Content.ToString();
			string notes = txtNotes.Text.Trim();

			var item = MenuItemDL.GetAllItems().FirstOrDefault(x => x.MenuItemID == itemId);
			if (item == null)
			{
				MessageBox.Show("Selected item not found in stock.");
				return;
			}

			if (returnQty > item.Quantity)
			{
				MessageBox.Show($"Return quantity cannot exceed current stock: {item.Quantity}", "Quantity Error", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			try
			{
				// Decrease stock
				StockDL.DecreaseStock(itemId, returnQty);

				// Record stock transaction
				StockDL.RecordStockTransaction(itemId, -returnQty, $"Vendor Return: {reason}. Notes: {notes}");

				// Record return in ReturnToVendor table and update StockReconciliationReport
				using (var con = new SqlConnection(DBConnection.connectionString))
				{
					con.Open();

					// Insert return record
					var insertCmd = new SqlCommand(@"
                        INSERT INTO ReturnToVendor (MenuItemID, QuantityReturned, Reason, Notes)
                        VALUES (@itemId, @quantityReturned, @reason, @notes)", con);

					insertCmd.Parameters.AddWithValue("@itemId", itemId);
					insertCmd.Parameters.AddWithValue("@quantityReturned", returnQty);
					insertCmd.Parameters.AddWithValue("@reason", reason ?? "");
					insertCmd.Parameters.AddWithValue("@notes", notes);
					insertCmd.ExecuteNonQuery();

					// Update or insert StockReconciliationReport
					var checkCmd = new SqlCommand(@"
                        SELECT COUNT(*) FROM StockReconciliationReport
                        WHERE MenuItemID = @itemId AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)", con);
					checkCmd.Parameters.AddWithValue("@itemId", itemId);

					int exists = (int)checkCmd.ExecuteScalar();

					if (exists > 0)
					{
						// If exists, update PurchaseReturns
						var updateCmd = new SqlCommand(@"
                            UPDATE StockReconciliationReport
                            SET PurchaseReturns = ISNULL(PurchaseReturns, 0) + @qty
                            WHERE MenuItemID = @itemId AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)", con);
						updateCmd.Parameters.AddWithValue("@itemId", itemId);
						updateCmd.Parameters.AddWithValue("@qty", returnQty);
						updateCmd.ExecuteNonQuery();
					}
					else
					{
						// Insert new record with basic values
						var insertRecCmd = new SqlCommand(@"
                            INSERT INTO StockReconciliationReport 
                            (MenuItemID, OpeningStock, Purchases, Sales, PurchaseReturns, SalesReturns, 
                             CalculatedClosing, PhysicalStock, Difference, Date)
                            VALUES 
                            (@itemId, 0, 0, 0, @qty, 0, 0, 0, 0, CAST(GETDATE() AS DATE))", con);
						insertRecCmd.Parameters.AddWithValue("@itemId", itemId);
						insertRecCmd.Parameters.AddWithValue("@qty", returnQty);
						insertRecCmd.ExecuteNonQuery();
					}
				}

				MessageBox.Show("Item return recorded successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

				// Reset form
				txtQuantity.Clear();
				txtNotes.Clear();
				cmbReason.SelectedIndex = -1;
				cmbItems.SelectedIndex = -1;

				// Reload items
				LoadItemsFromStock();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error while processing return: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}
	}
}
