﻿using Microsoft.Data.SqlClient;
using POS_APP.DL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for ExpenseDetails.xaml
    /// </summary>
    public partial class ExpenseDetails : Window
    {
        public ExpenseDetails()
        {
            InitializeComponent();
            this.KeyDown += Window_KeyDown;
            LoadCategoriesFromDB();
            LoadExpenses();
            dtpDate.SelectedDate = DateTime.Today;

        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cbCategory.Text))
            {
                MessageBox.Show("Please select or enter a category.");
                cbCategory.Focus();
                return;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                MessageBox.Show("Please enter a valid amount.");
                txtAmount.Focus();
                return;
            }

            try
            {
                using (var con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();
                    var cmd = new SqlCommand(
                        "INSERT INTO Expense (Category, Remarks, ExpenseDate, Amount) " +
                        "VALUES (@cat, @rem, @date, @amt)", con);

                    cmd.Parameters.AddWithValue("@cat", cbCategory.Text);
                    cmd.Parameters.AddWithValue("@rem", txtRemarks.Text);
                    cmd.Parameters.AddWithValue("@date", dtpDate.SelectedDate ?? DateTime.Now);
                    cmd.Parameters.AddWithValue("@amt", amount);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Expense added successfully!");
                LoadExpenses();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }
        private void LoadExpenses()
        {
            try
            {
                var dt = new DataTable();
                using (var con = new SqlConnection(DBConnection.connectionString))
                using (var da = new SqlDataAdapter("SELECT * FROM Expense", con))
                {
                    da.Fill(dt);
                }
                dgvExpenses.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading expenses: {ex.Message}");
            }
        }

        private void LoadCategoriesFromDB()
        {
            cbCategory.Items.Clear();
            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "SELECT CategoryName FROM ExpenseCategory";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cbCategory.Items.Add(reader["CategoryName"].ToString());
                }
                con.Close();
            }
        }

        private void ClearFields()
        {
            cbCategory.Text = "";
            txtRemarks.Text = "";
            txtAmount.Text = "";
            dtpDate.SelectedDate = DateTime.Now;
            cbCategory.Focus();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.A)
            {
                btnView_Click(null, null);
                e.Handled = true;
            }
        }
        private async void dtpDate_GotFocus(object sender, RoutedEventArgs e)
        {
            await Task.Delay(100);
            dtpDate.IsDropDownOpen = true;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dtpDate.SelectedDate = DateTime.Now;
            cbCategory.Focus();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            if (dpFromDate.SelectedDate == null || dpToDate.SelectedDate == null)
            {
                MessageBox.Show("Please select both From and To dates.");
                return;
            }

            DateTime fromDate = dpFromDate.SelectedDate.Value.Date;
            DateTime toDate = dpToDate.SelectedDate.Value.Date;

            try
            {
                var dt = new DataTable();
                using (var con = new SqlConnection(DBConnection.connectionString))
                {
                    string query = "SELECT * FROM Expense WHERE ExpenseDate BETWEEN @from AND @to";
                    using (var cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@from", fromDate);
                        cmd.Parameters.AddWithValue("@to", toDate);
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }
                    }
                }

                dgvExpenses.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error filtering expenses: " + ex.Message);
            }

        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            if (dgvExpenses.Items.Count == 0)
            {
                MessageBox.Show("No data to export.");
                return;
            }

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PDF Files (*.pdf)|*.pdf",
                FileName = "ExpenseReport.pdf"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    iTextSharp.text.Document doc = new iTextSharp.text.Document();
                    PdfWriter.GetInstance(doc, new FileStream(dialog.FileName, FileMode.Create));
                    doc.Open();

                    PdfPTable table = new PdfPTable(dgvExpenses.Columns.Count);
                    foreach (DataGridColumn column in dgvExpenses.Columns)
                    {
                        table.AddCell(new Phrase(column.Header.ToString()));
                    }

                    foreach (DataRowView rowView in dgvExpenses.ItemsSource)
                    {
                        foreach (var item in rowView.Row.ItemArray)
                        {
                            table.AddCell(new Phrase(item?.ToString() ?? ""));
                        }
                    }

                    doc.Add(new iTextSharp.text.Paragraph("Expense Report"));
                    doc.Add(new iTextSharp.text.Paragraph($"Date: {DateTime.Now}"));
                    doc.Add(new iTextSharp.text.Paragraph(" "));

                    doc.Add(table);
                    doc.Close();

                    MessageBox.Show("PDF exported successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error exporting to PDF: " + ex.Message);
                }
            }
        }
    }
}
