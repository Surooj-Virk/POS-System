﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using POS_APP.DL;
using System.Collections.Generic;

namespace POS_APP.UI
{
	public partial class StockReconciliationForm : Window
	{
		private DataTable categoriesTable;
		private DataTable reconciliationTable;

		public StockReconciliationForm()
		{
			InitializeComponent();

			if (!TestDatabaseConnection())
			{
				MessageBox.Show("Could not connect to database. Application will close.");
				this.Close();
				return;
			}

			txtCurrentDate.Text = DateTime.Now.ToString("dd-MMM-yyyy");
			LoadCategories();
		}

		private bool TestDatabaseConnection()
		{
			try
			{
				using var con = new SqlConnection(DBConnection.connectionString);
				con.Open();
				return true;
			}
			catch
			{
				return false;
			}
		}

		private void LoadCategories()
		{
			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();
				SqlCommand cmd = new SqlCommand("SELECT CategoryID, CategoryName FROM ItemCategories", con);
				SqlDataAdapter da = new SqlDataAdapter(cmd);
				categoriesTable = new DataTable();
				da.Fill(categoriesTable);

				if (categoriesTable.Rows.Count > 0)
				{
					cmbCategories.ItemsSource = categoriesTable.DefaultView;
					cmbCategories.DisplayMemberPath = "CategoryName";
					cmbCategories.SelectedValuePath = "CategoryID";
					cmbCategories.SelectedIndex = 0;
				}
				else
				{
					MessageBox.Show("No categories found in database.");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading categories: {ex.Message}");
			}
		}

		private void cmbCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				if (cmbCategories.SelectedValue != null)
				{
					int categoryId = Convert.ToInt32(cmbCategories.SelectedValue);
					LoadReconciliationItemsByCategory(categoryId);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading items: {ex.Message}");
			}
		}

		private void LoadReconciliationItemsByCategory(int categoryId)
		{
			try
			{
				string? categoryName = "";
				using (SqlConnection con1 = new SqlConnection(DBConnection.connectionString))
				{
					con1.Open();
					SqlCommand cmd1 = new SqlCommand("SELECT CategoryName FROM ItemCategories WHERE CategoryID = @categoryId", con1);
					cmd1.Parameters.AddWithValue("@categoryId", categoryId);
					categoryName = cmd1.ExecuteScalar()?.ToString();
				}

				if (!string.IsNullOrEmpty(categoryName))
				{
					using SqlConnection con = new SqlConnection(DBConnection.connectionString);
					con.Open();

					SqlCommand cmd = new SqlCommand(@"
                SELECT 
                    mi.MenuItemID,
                    mi.ItemName,
                    mi.Category,
                    mi.Unit,

                    ISNULL((SELECT TOP 1 PhysicalStock FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND Date < CAST(GETDATE() AS DATE)
                            ORDER BY Date DESC), 0) AS Opening,

                    ISNULL((SELECT Purchases FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)), 0) AS ReceivedFromVendor,

                 ISNULL((SELECT SUM(ReturnQuantity) FROM ReturnTransactions 
WHERE MenuItemID = mi.MenuItemID AND CAST(ReturnDate AS DATE) = CAST(GETDATE() AS DATE)), 0) AS CustomerReturn,


                    ISNULL((SELECT Sales FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)), 0) AS Sales,

ISNULL((SELECT SUM(QuantityReturned) FROM ReturnToVendor 
WHERE MenuItemID = mi.MenuItemID AND CAST(ReturnDate AS DATE) = CAST(GETDATE() AS DATE)), 0) AS ReturnToVendor,

                    0 AS SystemQty,

                    ISNULL((SELECT PhysicalStock FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)), NULL) AS PhysicalQty,

                    ISNULL((SELECT Difference FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)), NULL) AS Variance,

                    ISNULL((SELECT PhysicalStock FROM StockReconciliationReport 
                            WHERE MenuItemID = mi.MenuItemID AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)), NULL) AS Closing

                FROM MenuItems mi
                JOIN ItemCategories ic ON mi.Category = ic.CategoryName
                WHERE ic.CategoryID = @categoryId
                ORDER BY mi.ItemName", con);

					cmd.Parameters.AddWithValue("@categoryId", categoryId);
					SqlDataAdapter da = new SqlDataAdapter(cmd);
					reconciliationTable = new DataTable();
					da.Fill(reconciliationTable);

					foreach (DataRow row in reconciliationTable.Rows)
					{
						int opening = Convert.ToInt32(row["Opening"]);
						int receivedFromVendor = Convert.ToInt32(row["ReceivedFromVendor"]);
						int customerReturn = Convert.ToInt32(row["CustomerReturn"]);
						int sales = Convert.ToInt32(row["Sales"]);
						int returnToVendor = Convert.ToInt32(row["ReturnToVendor"]);

						int systemQty = Math.Max(0, opening + receivedFromVendor + customerReturn - sales - returnToVendor);
						row["SystemQty"] = systemQty;

						// No need to overwrite PhysicalQty, Variance, Closing here 
						// because we already loaded saved values from DB (could be null)
					}

					ReconciliationGrid.ItemsSource = reconciliationTable.DefaultView;
				}
				else
				{
					MessageBox.Show("Selected category not found.");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading reconciliation items: {ex.Message}");
			}
		}
		private void btnReconcile_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (reconciliationTable == null || reconciliationTable.Rows.Count == 0)
				{
					MessageBox.Show("No items to reconcile.");
					return;
				}

				DateTime reconciliationDate = DateTime.Now.Date;

				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();
				using SqlTransaction transaction = con.BeginTransaction();

				try
				{
					var rowsToDelete = new List<DataRow>();

					foreach (DataRow row in reconciliationTable.Rows)
					{
						if (row.RowState == DataRowState.Deleted || row.IsNull("PhysicalQty")) continue;

						int menuItemId = Convert.ToInt32(row["MenuItemID"]);
						int opening = Convert.ToInt32(row["Opening"]);
						int receivedFromVendor = Convert.ToInt32(row["ReceivedFromVendor"]);
						int customerReturn = Convert.ToInt32(row["CustomerReturn"]);
						int sales = Convert.ToInt32(row["Sales"]);
						int returnToVendor = Convert.ToInt32(row["ReturnToVendor"]);

						int systemQty = Math.Max(0, opening + receivedFromVendor + customerReturn - sales - returnToVendor);

						int physicalQty = int.TryParse(row["PhysicalQty"]?.ToString(), out int pq) ? Math.Max(0, pq) : 0;

						int variance = physicalQty - systemQty;

						row["SystemQty"] = systemQty;
						row["Variance"] = variance;
						row["Closing"] = physicalQty;

						// DELETE if PhysicalQty = 0
						if (physicalQty == 0)
						{
							SqlCommand deleteCmd = new SqlCommand(@"
                        DELETE FROM StockReconciliationReport 
                        WHERE MenuItemID = @menuItemId AND CAST(Date AS DATE) = @date", con, transaction);
							deleteCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
							deleteCmd.Parameters.AddWithValue("@date", reconciliationDate);
							deleteCmd.ExecuteNonQuery();

							rowsToDelete.Add(row);
							continue;
						}

						// Check if row exists
						SqlCommand checkCmd = new SqlCommand(@"
                    SELECT COUNT(*) FROM StockReconciliationReport 
                    WHERE MenuItemID = @menuItemId AND CAST(Date AS DATE) = @date", con, transaction);
						checkCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
						checkCmd.Parameters.AddWithValue("@date", reconciliationDate);

						int count = (int)checkCmd.ExecuteScalar();

						if (count > 0)
						{
							// Update existing
							SqlCommand updateCmd = new SqlCommand(@"
                        UPDATE StockReconciliationReport
                        SET OpeningStock = @opening,
                            Purchases = @purchases,
                            Sales = @sales,
                            PurchaseReturns = @purchaseReturns,
                            SalesReturns = @salesReturns,
                            CalculatedClosing = @calculatedClosing,
                            PhysicalStock = @physicalStock,
                            Difference = @difference,
                            Date = @date
                        WHERE MenuItemID = @menuItemId AND CAST(Date AS DATE) = @date", con, transaction);

							updateCmd.Parameters.AddWithValue("@opening", opening);
							updateCmd.Parameters.AddWithValue("@purchases", receivedFromVendor);
							updateCmd.Parameters.AddWithValue("@sales", sales);
							updateCmd.Parameters.AddWithValue("@purchaseReturns", returnToVendor);
							updateCmd.Parameters.AddWithValue("@salesReturns", customerReturn);
							updateCmd.Parameters.AddWithValue("@calculatedClosing", systemQty);
							updateCmd.Parameters.AddWithValue("@physicalStock", physicalQty);
							updateCmd.Parameters.AddWithValue("@difference", variance);
							updateCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
							updateCmd.Parameters.AddWithValue("@date", reconciliationDate);
							updateCmd.ExecuteNonQuery();
						}
						else
						{
							// Insert new
							SqlCommand insertCmd = new SqlCommand(@"
                        INSERT INTO StockReconciliationReport
                        (MenuItemID, OpeningStock, Purchases, Sales, PurchaseReturns, SalesReturns,
                        CalculatedClosing, PhysicalStock, Difference, Date)
                        VALUES
                        (@menuItemId, @opening, @purchases, @sales, @purchaseReturns, @salesReturns,
                        @calculatedClosing, @physicalStock, @difference, @date)", con, transaction);

							insertCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
							insertCmd.Parameters.AddWithValue("@opening", opening);
							insertCmd.Parameters.AddWithValue("@purchases", receivedFromVendor);
							insertCmd.Parameters.AddWithValue("@sales", sales);
							insertCmd.Parameters.AddWithValue("@purchaseReturns", returnToVendor);
							insertCmd.Parameters.AddWithValue("@salesReturns", customerReturn);
							insertCmd.Parameters.AddWithValue("@calculatedClosing", systemQty);
							insertCmd.Parameters.AddWithValue("@physicalStock", physicalQty);
							insertCmd.Parameters.AddWithValue("@difference", variance);
							insertCmd.Parameters.AddWithValue("@date", reconciliationDate);
							insertCmd.ExecuteNonQuery();
						}
					}

					transaction.Commit();

					// Remove rows with PhysicalQty = 0 from DataTable (UI)
					foreach (var row in rowsToDelete)
					{
						reconciliationTable.Rows.Remove(row);
					}

					// Accept changes to keep DataTable state consistent
					reconciliationTable.AcceptChanges();

					// NO reloading of data here to keep user edits visible
					// int selectedCategoryId = cmbCategories.SelectedValue != null ? Convert.ToInt32(cmbCategories.SelectedValue) : 0;
					// if (selectedCategoryId > 0)
					// {
					//     LoadReconciliationItemsByCategory(selectedCategoryId);
					// }

					MessageBox.Show("Stock reconciliation saved successfully.");
				}
				catch (Exception ex)
				{
					transaction.Rollback();
					MessageBox.Show($"Error during reconciliation: {ex.Message}");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Unexpected error: {ex.Message}");
			}
		}
		private void ReconciliationGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
		{
			if (e.Column.Header.ToString() == "Physical Qty")
			{
				var rowView = (DataRowView)e.Row.Item;

				if (int.TryParse(((TextBox)e.EditingElement).Text, out int newPhysicalQty))
				{
					int systemQty = Convert.ToInt32(rowView["SystemQty"]);
					int variance = newPhysicalQty - systemQty;

					rowView["PhysicalQty"] = newPhysicalQty;
					rowView["Variance"] = variance;
					rowView["Closing"] = newPhysicalQty;

					// Optional: mark row for deletion in grid only if variance = 0
					// Commented out so user can keep rows with zero variance if they want
					// if (variance == 0)
					// {
					// 	rowView.Row.Delete();
					// }
				}
				else
				{
					rowView["PhysicalQty"] = DBNull.Value;
					rowView["Variance"] = DBNull.Value;
					rowView["Closing"] = DBNull.Value;
				}
			}
		}
	}
}
