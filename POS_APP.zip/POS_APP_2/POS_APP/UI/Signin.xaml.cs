﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using POS_APP.DL;

namespace POS_APP.UI
{
    public partial class Signin : Window
    {
        public static class Session
        {
            public static string Username { get; set; }
            public static int UserId { get; set; }
            public static string Role { get; set; }

            public static void Clear()
            {
                Username = string.Empty;
                UserId = 0;
                Role = string.Empty;
            }
        }

        public Signin()
        {
            InitializeComponent();
            Session.Clear();
            checkbox1_CheckedChanged(null, null); 
        }

        private void ClearFields()
        {
            txtUsername.Text = "";
            txtPassword.Clear();
            txtVisiblePassword.Text = "";
        }

        private void checkbox1_CheckedChanged(object sender, RoutedEventArgs e)
        {
            if (checkbox1 == null || txtPassword == null || txtVisiblePassword == null)
                return;

            try
            {
                if (checkbox1.IsChecked == true)
                {
                    txtVisiblePassword.Text = txtPassword.Password;
                    txtPassword.Visibility = Visibility.Collapsed;
                    txtVisiblePassword.Visibility = Visibility.Visible;
                }
                else
                {
                    txtPassword.Password = txtVisiblePassword.Text;
                    txtVisiblePassword.Visibility = Visibility.Collapsed;
                    txtPassword.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error toggling password visibility: {ex.Message}");
            }
        }

        private void btnSignin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername?.Text?.Trim() ?? "";
            string password = checkbox1?.IsChecked == true
                ? txtVisiblePassword?.Text?.Trim() ?? ""
                : txtPassword?.Password?.Trim() ?? "";

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("All fields are required.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    string query = "SELECT UserID, Role, IsApproved FROM Users WHERE Username = @username AND Password = @password";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bool isApproved = reader.GetBoolean(2);

                            if (!isApproved)
                            {
                                MessageBox.Show("Your account is pending approval. Please contact administrator.",
                                    "Account Pending", MessageBoxButton.OK, MessageBoxImage.Information);
                                return;
                            }

                            Session.UserId = reader.GetInt32(0);
                            Session.Role = reader.GetString(1);
                            Session.Username = username;

                            MessageBox.Show($"Login successful! Welcome {Session.Username} ({Session.Role})");

                            Window dashboard = Session.Role == "Admin"
                                ? new AdminPanel()
                                : new CashierPanel();

                            dashboard.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username or Password!", "Error",
                                MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Login failed: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                ClearFields();
            }
        }

        private void btnSignup_Click(object sender, RoutedEventArgs e)
        {
            var signup = new Signup();
            signup.Show();
            this.Close();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}