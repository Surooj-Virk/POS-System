﻿using System.Windows;

namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for CashierPanel.xaml
    /// </summary>
    public partial class CashierPanel : Window
    {
        private Window _currentChildWindow;

        public CashierPanel()
        {
            InitializeComponent();
            ShowDashboard();
        }

        private void ShowChildWindow(Window window)
        {
            // Close current child window if exists
            _currentChildWindow?.Close();

            // Configure new window
            //window.Owner = this;
            window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            window.WindowStyle = WindowStyle.None;
            window.ResizeMode = ResizeMode.NoResize;
            window.ShowInTaskbar = false;

            // Add to content container
            ContentContainer.Content = window.Content;
            _currentChildWindow = window;

            // Handle window closed event
            window.Closed += (s, e) => {
                if (ContentContainer.Content == window.Content)
                    ContentContainer.Content = null;
            };
        }

        private void ShowDashboard()
        {
            var dashboard = new CashierDashboard();
            ShowChildWindow(dashboard);
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e) => ShowDashboard();

        private void Orders_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new OrderForm());

        private void AccountSettings_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new ChangePassword());

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var login = new Signin();
            login.Show();
            this.Close();
        }
    }
}