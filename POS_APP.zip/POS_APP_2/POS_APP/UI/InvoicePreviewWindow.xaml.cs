﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for InvoicePreviewWindow.xaml
    /// </summary>
    public partial class InvoicePreviewWindow : Window
    {
        private int _orderId;
        private string _invoiceText; // Store invoice text for printing

        public InvoicePreviewWindow(int orderId, string invoiceText)
        {
            InitializeComponent();
            _orderId = orderId;
            _invoiceText = invoiceText;
            SetInvoiceContent(invoiceText);
        }

        public void SetInvoiceContent(string invoiceText)
        {
            // Create a FlowDocument to display the invoice
            var doc = new FlowDocument
            {
                FontFamily = new FontFamily("Courier New"),
                FontSize = 12,
                PagePadding = new Thickness(15),
                TextAlignment = TextAlignment.Left,
                LineHeight = 12,
                PageWidth = 900
            };

            // Add header
            var header = new Paragraph();
            try
            {
                var logo = new Image
                {
                    Source = new BitmapImage(new Uri("pack://application:,,,/Resources/pizza_albaik.PNG")),
                    Width = 150,
                    Height = 150,
                    Stretch = Stretch.Uniform
                };
                header.Inlines.Add(logo);
            }
            catch
            {
                header.Inlines.Add(new Run("PIZZA ALBAIK") { FontSize = 20, FontWeight = FontWeights.Bold });
            }

            doc.Blocks.Add(header);
            doc.Blocks.Add(new Paragraph(new Run(invoiceText)));

            // Display in a RichTextBox or FlowDocumentScrollViewer
            var viewer = new FlowDocumentScrollViewer
            {
                Document = doc,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };

            this.Content = new Grid
            {
                Children =
            {
                viewer,
                new Button
                {
                    Content = "Print Invoice",
                    HorizontalAlignment = HorizontalAlignment.Right,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Margin = new Thickness(10),
                    Padding = new Thickness(10, 5, 10, 5),
                    Command = new RelayCommand(() =>
                    {
                        PrintInvoice(); // Call PrintInvoice when button is clicked
                        this.DialogResult = true;
                        this.Close();
                    })
                }
            }
            };

            this.Width = 1000;
            this.Height = 700;
            this.Title = $"Invoice Preview - Order #{_orderId}";
        }
        private void PrintInvoice()
        {
            try
            {
                PrintDialog printDialog = new PrintDialog();
                if (printDialog.ShowDialog() == true)
                {
                    FlowDocument doc = new FlowDocument
                    {
                        FontFamily = new FontFamily("Courier New"),
                        FontSize = 12,
                        PagePadding = new Thickness(25),
                        ColumnWidth = double.PositiveInfinity // Prevent text wrapping
                    };

                    // Add invoice text to the document
                    Paragraph para = new Paragraph(new Run(_invoiceText));
                    doc.Blocks.Add(para);

                    // Print the document
                    printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, $"Invoice #{_orderId}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Printing failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class RelayCommand : ICommand
        {
            private readonly Action _execute;

            public RelayCommand(Action execute)
            {
                _execute = execute;
            }

            public event EventHandler CanExecuteChanged;

            public bool CanExecute(object parameter) => true;

            public void Execute(object parameter) => _execute();
        }
    }

