﻿using POS_APP.BL;
using POS_APP.DL;
using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace POS_APP.UI
{
    public partial class SalesReportForm : Window
    {
        private List<SalesReport> currentReport;

        public SalesReportForm()
        {
            InitializeComponent();
            Loaded += SalesReportWindow_Load;
            LoadItemNames();
            dgvReport.IsReadOnly = true;
            dtpFrom.SelectedDate = DateTime.Today;
            dtpTo.SelectedDate = DateTime.Today;
        }

        private void SalesReportWindow_Load(object sender, RoutedEventArgs e)
        {
            LoadItemNames();
            lstItems.Focus();
            btnView.IsEnabled = false;
            btnPrint.IsEnabled = false;
        }

        private void LoadItemNames()
        {
            var allItems = MenuItemDL.GetAllItems();
            lstItems.Items.Clear();
            lstItems.Items.Add("All Items");

            foreach (var item in allItems)
            {
                lstItems.Items.Add(item.Item);
            }

            lstItems.SelectionMode = SelectionMode.Extended;
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            if (!dtpFrom.SelectedDate.HasValue || !dtpTo.SelectedDate.HasValue)
            {
                MessageBox.Show("Please select both 'From' and 'To' dates before viewing the report.",
                              "Date Selection Required",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                return;
            }

            DateTime from = dtpFrom.SelectedDate.Value;
            DateTime to = dtpTo.SelectedDate.Value.AddDays(1).AddSeconds(-1);

            if (to < from)
            {
                MessageBox.Show("The 'To' date cannot be before the 'From' date.",
                              "Invalid Date Range",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                return;
            }

            var selectedItems = lstItems.SelectedItems.Cast<string>().ToList();
            if (selectedItems.Count == 0)
            {
                MessageBox.Show("Please select at least one item from the list.",
                               "No Item Selected",
                               MessageBoxButton.OK,
                               MessageBoxImage.Warning);
                return;
            }

            bool isAllSelected = selectedItems.Contains("All Items") || selectedItems.Count == lstItems.Items.Count;

            currentReport = SalesBL.GetSalesReport(from, to);

            if (!isAllSelected)
            {
                currentReport = currentReport.Where(r => selectedItems.Contains(r.ItemName)).ToList();
            }

            dgvReport.ItemsSource = currentReport;
            lblRevenue.Content = "Rs. " + currentReport.Sum(r => r.TotalAmount).ToString("N2");
            btnPrint.IsEnabled = currentReport != null && currentReport.Count > 0;
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            if (currentReport == null || currentReport.Count == 0)
            {
                MessageBox.Show("No report data available to print.", "Nothing to Print", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                FlowDocument doc = GenerateDocument();
                doc.PagePadding = new Thickness(50);
                printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Sales Report");
            }
        }

        private FlowDocument GenerateDocument()
        {
            FlowDocument doc = new FlowDocument
            {
                PagePadding = new Thickness(50),
                ColumnWidth = double.PositiveInfinity,
                FontFamily = new FontFamily("Arial")
            };

            // Header
            Paragraph header = new Paragraph
            {
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 20)
            };
            header.Inlines.Add(new Run("PIZZA ALBAIK - SALES REPORT"));
            doc.Blocks.Add(header);

            // Date range
            Paragraph dateRange = new Paragraph
            {
                FontSize = 12,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 15)
            };
            dateRange.Inlines.Add(new Run($"From: {dtpFrom.SelectedDate?.ToString("dd-MMM-yyyy")} to {dtpTo.SelectedDate?.ToString("dd-MMM-yyyy")}"));
            doc.Blocks.Add(dateRange);

            // Create table
            Table table = new Table
            {
                CellSpacing = 0,
                Margin = new Thickness(0, 0, 0, 20)
            };

            // Add columns with better distribution
            table.Columns.Add(new TableColumn { Width = new GridLength(3, GridUnitType.Star) }); 
            table.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });  
            table.Columns.Add(new TableColumn { Width = new GridLength(1.8, GridUnitType.Star) }); 
            table.Columns.Add(new TableColumn { Width = new GridLength(1.8, GridUnitType.Star) }); 
            table.Columns.Add(new TableColumn { Width = new GridLength(1.8, GridUnitType.Star) }); 
            table.Columns.Add(new TableColumn { Width = new GridLength(2, GridUnitType.Star) });   
            table.Columns.Add(new TableColumn { Width = new GridLength(2, GridUnitType.Star) });  
            table.Columns.Add(new TableColumn { Width = new GridLength(1.6, GridUnitType.Star) }); 

            doc.Blocks.Add(table);

            // Table header
            TableRowGroup rowGroup = new TableRowGroup();
            table.RowGroups.Add(rowGroup);

            TableRow headerRow = new TableRow
            {
                Background = Brushes.LightGray,
                FontWeight = FontWeights.Bold
            };

            // Use shorter headers or non-breaking spaces
            string[] headers = { "Item", "Qty", "Original", "Discount", "Final Amt", "Date", "Sold By", "Payment" };
            foreach (var headerText in headers)
            {
                headerRow.Cells.Add(new TableCell(new Paragraph(new Run(headerText))
                {
                    TextAlignment = (headerText == "Qty" || headerText == "Original" ||
                                    headerText == "Discount" || headerText == "Final") ?
                                    TextAlignment.Right : TextAlignment.Left,
                    Padding = new Thickness(5)
                }));
            }
            rowGroup.Rows.Add(headerRow);
            // Table data
            foreach (var report in currentReport)
            {
                TableRow row = new TableRow();

                row.Cells.Add(new TableCell(new Paragraph(new Run(report.ItemName)) { Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.QuantitySold.ToString()))
                { TextAlignment = TextAlignment.Right, Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.OriginalAmount.ToString("N2")))
                { TextAlignment = TextAlignment.Right, Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.DiscountAmount.ToString("N2")))
                { TextAlignment = TextAlignment.Right, Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.FinalAmount.ToString("N2")))
                { TextAlignment = TextAlignment.Right, Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.Date.ToString("dd-MMM-yyyy hh:mm tt")))
                { Padding = new Thickness(5) }));
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.SoldBy))) { Padding = new Thickness(5) });
                row.Cells.Add(new TableCell(new Paragraph(new Run(report.PaymentMethod))) { Padding = new Thickness(5) });

                rowGroup.Rows.Add(row);
            }

            // Summary
            Paragraph summary = new Paragraph
            {
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Right,
                Margin = new Thickness(0, 20, 0, 0)
            };
            summary.Inlines.Add(new Run($"Gross Sales: Rs. {currentReport.Sum(r => r.OriginalAmount).ToString("N2")}\n"));
            summary.Inlines.Add(new Run($"Total Discounts: Rs. {currentReport.Sum(r => r.DiscountAmount).ToString("N2")}\n"));
            summary.Inlines.Add(new Run($"Net Sales: Rs. {currentReport.Sum(r => r.FinalAmount).ToString("N2")}"));
            doc.Blocks.Add(summary);

            // Footer
            Paragraph footer = new Paragraph
            {
                FontSize = 10,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 30, 0, 0)
            };
            footer.Inlines.Add(new Run($"Generated on {DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt")}"));
            doc.Blocks.Add(footer);

            return doc;
        }
        private void lstItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstItems.SelectedItems.Contains("All Items"))
            {
                lstItems.SelectionChanged -= lstItems_SelectionChanged;
                lstItems.SelectedItems.Clear();
                foreach (var item in lstItems.Items)
                {
                    lstItems.SelectedItems.Add(item);
                }
                lstItems.SelectionChanged += lstItems_SelectionChanged;
            }
        }

        private void dtpFrom_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ValidateDates();
        }

        private void dtpTo_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ValidateDates();
        }

        private void ValidateDates()
        {
            btnView.IsEnabled = dtpFrom.SelectedDate.HasValue && dtpTo.SelectedDate.HasValue;
        }

        private void OpenDatePickerCalendar(DatePicker datePicker)
        {
            datePicker.Focus();
            Dispatcher.BeginInvoke(new Action(() =>
            {
                datePicker.IsDropDownOpen = true;
            }), System.Windows.Threading.DispatcherPriority.Input);
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (lstItems.IsFocused && e.Key == Key.Enter)
            {
                if (lstItems.SelectedIndex >= 0)
                {
                    dtpFrom.Focus();
                    OpenDatePickerCalendar(dtpFrom);
                }
                e.Handled = true;
            }
            else if (dtpFrom.IsFocused && e.Key == Key.Enter)
            {
                OpenDatePickerCalendar(dtpFrom);
                e.Handled = true;
            }
            else if (dtpTo.IsFocused && e.Key == Key.Enter)
            {
                OpenDatePickerCalendar(dtpTo);
                e.Handled = true;
            }
            else if (e.Key == Key.P && btnPrint.IsEnabled)
            {
                btnPrint_Click(null, null);
                e.Handled = true;
            }
            else if (e.Key == Key.S && btnView.IsEnabled)
            {
                btnView_Click(null, null);
                e.Handled = true;
            }
        }

    }
}
