﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using POS_APP.DL;


namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for AdminDashboard.xaml
    /// </summary>
    public partial class AdminDashboard : Window
    {
        public AdminDashboard()
        {
            InitializeComponent();
            LoadDashboardData();
        }
        private void LoadDashboardData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();

                    // Total Items
                    SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*) FROM MenuItems", con);
                    txtTotalItems.Text = cmd1.ExecuteScalar().ToString();

                    // Sales Today
                    SqlCommand cmd2 = new SqlCommand("SELECT SUM(TotalAmount) FROM Orders WHERE CAST(OrderDate AS DATE) = CAST(GETDATE() AS DATE)", con);
                    txtSalesToday.Text = cmd2.ExecuteScalar()?.ToString() ?? "0";

                    // Remaining Stock
                    SqlCommand cmd3 = new SqlCommand("SELECT SUM(Quantity) FROM MenuItems", con);
                    txtRemainingStock.Text = cmd3.ExecuteScalar()?.ToString() ?? "0";

                    // Total Expenses
                    SqlCommand cmd4 = new SqlCommand("SELECT SUM(Amount) FROM Expense WHERE CAST(ExpenseDate AS DATE) = CAST(GETDATE() AS DATE)", con);
                    txtExpenses.Text = cmd4.ExecuteScalar()?.ToString() ?? "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard: " + ex.Message);
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
