﻿using POS_APP.DL;       // Data Layer access
using POS_APP.Models;   // Your OrderItem model
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace POS_APP.UI
{
	/// <summary>
	/// Interaction logic for ReturnFromCustomerForm.xaml
	/// </summary>
	public partial class ReturnFromCustomerForm : Window
	{
		// ObservableCollection for automatic UI updates
		private ObservableCollection<ReturnOrderItem> orderItems = new ObservableCollection<ReturnOrderItem>();

		public ReturnFromCustomerForm()
		{
			InitializeComponent();
			dgOrderItems.ItemsSource = orderItems;
			orderItems.CollectionChanged += (s, e) => UpdateTotalRefund();
		}

		private void LoadOrderButton_Click(object sender, RoutedEventArgs e)
		{
			if (!int.TryParse(txtOrderID.Text.Trim(), out int orderId))
			{
				MessageBox.Show("Please enter a valid Order ID.");
				return;
			}

			try
			{
				orderItems.Clear();

				// Fetch order items by OrderId (you must implement this method)
				var items = OrderDL.GetOrderItemsByOrderId(orderId);

				if (items == null || !items.Any())
				{
					MessageBox.Show("No order items found for this Order ID.");
					return;
				}

				// Populate observable collection with ReturnOrderItem wrappers
				foreach (var item in items)
				{
					var returnItem = new ReturnOrderItem
					{
						MenuItemID = item.MenuItemID,
						ItemName = item.ItemName,
						Category = item.Category,
						Quantity = item.Quantity,
						UnitPrice = item.UnitPrice,
						ReturnQuantity = 0
					};
					// Subscribe to property changed to update refund when return quantity changes
					returnItem.PropertyChanged += ReturnItem_PropertyChanged;
					orderItems.Add(returnItem);
				}

				UpdateTotalRefund();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Failed to load order items: {ex.Message}");
			}
		}

		private void ReturnItem_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == nameof(ReturnOrderItem.ReturnQuantity))
			{
				var item = sender as ReturnOrderItem;
				if (item.ReturnQuantity > item.Quantity)
				{
					MessageBox.Show($"Return quantity cannot exceed quantity sold ({item.Quantity}).");
					item.ReturnQuantity = item.Quantity;  // reset to max allowed
				}

				item.UpdateRefundAmount();
				UpdateTotalRefund();
			}
		}

		private void UpdateTotalRefund()
		{
			decimal totalRefund = orderItems.Sum(x => x.RefundAmount);
			txtTotalRefund.Text = totalRefund.ToString("C");
		}

		private void ConfirmReturnButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				var itemsToReturn = orderItems.Where(x => x.ReturnQuantity > 0).ToList();

				if (!itemsToReturn.Any())
				{
					MessageBox.Show("Please enter return quantity for at least one item.");
					return;
				}

				// Process return logic: increase stock and record return transaction
				foreach (var item in itemsToReturn)
				{
					// Increase stock quantity in DB
					bool success = StockDL.IncreaseStock(item.MenuItemID, item.ReturnQuantity);
					if (!success)
					{
						MessageBox.Show($"Failed to update stock for item {item.ItemName}");
						return;
					}

					// Record return transaction in DB (you must implement this)
					OrderDL.RecordReturnTransaction(txtOrderID.Text.Trim(), item.MenuItemID, item.ReturnQuantity, item.UnitPrice);
				}

				MessageBox.Show("Return processed successfully.");

				// Reset form
				orderItems.Clear();
				txtOrderID.Clear();
				txtTotalRefund.Text = string.Empty;
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error processing return: {ex.Message}");
			}
		}
	}

	/// <summary>
	/// Wrapper class for order item with return quantity and refund calculation.
	/// Implements INotifyPropertyChanged to update UI dynamically.
	/// </summary>
	public class ReturnOrderItem : INotifyPropertyChanged
	{
		public int MenuItemID { get; set; }
		public string ItemName { get; set; }
		public string Category { get; set; }
		public int Quantity { get; set; }       // Quantity sold
		public decimal UnitPrice { get; set; }

		private int returnQuantity;
		public int ReturnQuantity
		{
			get => returnQuantity;
			set
			{
				if (returnQuantity != value)
				{
					returnQuantity = value;
					OnPropertyChanged(nameof(ReturnQuantity));
				}
			}
		}

		private decimal refundAmount;
		public decimal RefundAmount
		{
			get => refundAmount;
			private set
			{
				if (refundAmount != value)
				{
					refundAmount = value;
					OnPropertyChanged(nameof(RefundAmount));
				}
			}
		}

		public void UpdateRefundAmount()
		{
			RefundAmount = UnitPrice * ReturnQuantity;
		}

		public event PropertyChangedEventHandler PropertyChanged;
		protected void OnPropertyChanged(string propName)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
		}
	}
}
