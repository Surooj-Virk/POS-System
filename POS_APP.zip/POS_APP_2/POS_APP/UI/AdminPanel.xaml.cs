﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using POS_APP.UI;
namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {
        private Window _currentChildWindow;

        public AdminPanel()
        {
            InitializeComponent();
            ShowDashboard();
        }
        private void ShowChildWindow(Window window)
        {
            // Close current child window if exists
            _currentChildWindow?.Close();

            // Configure new window
            //window.Owner = this;
            window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            window.WindowStyle = WindowStyle.None;
            window.ResizeMode = ResizeMode.NoResize;
            window.ShowInTaskbar = false;

            // Add to content container
            ContentContainer.Content = window.Content;
            _currentChildWindow = window;

            // Handle window closed event
            window.Closed += (s, e) => {
                if (ContentContainer.Content == window.Content)
                    ContentContainer.Content = null;
            };
        }
        private void ShowDashboard()
        {
            var dashboard = new AdminDashboard();
            ShowChildWindow(dashboard);
        }
        private void Dashboard_Click(object sender, RoutedEventArgs e) => ShowDashboard();
        private void RegisterItems_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new ReceiveStockFromVendor());
        private void ItemCategories_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new AddItemCategory());
        private void ManageStock_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new StockReconciliationForm());
        private void ManageOrders_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new OrderForm());
        private void TrackSales_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new SalesReportForm());
        private void AddExpenses_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new ExpenseDetails());
        private void ExpenseCategories_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new AddExpenseCategory());
        private void ManageApprovals_Click(object sender, RoutedEventArgs e) => ShowChildWindow(new AdminApproval());

        private void AccountInfo_Click(object sender, RoutedEventArgs e)
        {
            // Implement account info window
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var login = new Signin();
            login.Show();
            this.Close();
        }
		private void ReturntoVendor_Click(object sender, RoutedEventArgs e)
		{
			ShowChildWindow(new ReturnToVendorForm());
		}

		private void ReturnfromCust_Click(object sender, RoutedEventArgs e)
		{
			ShowChildWindow(new ReturnFromCustomerForm());
		}

		private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }
        private void UpdateCredentials_Click(object sender, RoutedEventArgs e)
        {
            ShowChildWindow(new ChangePassword());
        }

        private void ApproveUsers_Click(object sender, RoutedEventArgs e)
        {
            ShowChildWindow(new AdminApproval());
        }

    }
}
