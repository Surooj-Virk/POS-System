﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using POS_APP.DL;

namespace POS_APP.UI
{
    /// <summary>
    /// Interaction logic for AddItemCategory.xaml
    /// </summary>
    public partial class AddItemCategory : Window
    {
        private int selectedCategoryId = -1;

        public AddItemCategory()
        {
            InitializeComponent();
            LoadCategories();
            txtCategoryName.Focus();
        }
        public class Category
        {
            public int CategoryID { get; set; }
            public string CategoryName { get; set; }
        }

        private void LoadCategories()
        {
            List<Category> categories = new List<Category>();
            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM ItemCategories", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    categories.Add(new Category
                    {
                        CategoryID = Convert.ToInt32(reader["CategoryID"]),
                        CategoryName = reader["CategoryName"].ToString()
                    });
                }
            }

            dgvCategories.ItemsSource = categories;
        }

        private void ClearForm()
        {
            txtCategoryName.Clear();
            selectedCategoryId = -1;
            dgvCategories.UnselectAll();
            txtCategoryName.Focus();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string categoryName = txtCategoryName.Text.Trim();
            if (string.IsNullOrWhiteSpace(categoryName))
            {
                MessageBox.Show("Category name is required.");
                return;
            }

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO ItemCategories (CategoryName) VALUES (@name)", con);
                cmd.Parameters.AddWithValue("@name", categoryName);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category added successfully.");
                    LoadCategories();
                    ClearForm();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627)
                        MessageBox.Show("This category already exists.");
                    else
                        MessageBox.Show("Error: " + ex.Message);
                }
            }

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category to update.");
                return;
            }

            string categoryName = txtCategoryName.Text.Trim();
            if (string.IsNullOrWhiteSpace(categoryName))
            {
                MessageBox.Show("Category name is required.");
                return;
            }

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE ItemCategories SET CategoryName=@name WHERE CategoryID=@id", con);
                cmd.Parameters.AddWithValue("@name", categoryName);
                cmd.Parameters.AddWithValue("@id", selectedCategoryId);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category updated successfully.");
                    LoadCategories();
                    ClearForm();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627)
                        MessageBox.Show("This category already exists.");
                    else
                        MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category to delete.");
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this category?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM ItemCategories WHERE CategoryID=@id", con);
                    cmd.Parameters.AddWithValue("@id", selectedCategoryId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category deleted successfully.");
                    LoadCategories();
                    ClearForm();
                }
            }
        }

        private void dgvCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvCategories.SelectedItem is Category selected)
            {
                selectedCategoryId = selected.CategoryID;
                txtCategoryName.Text = selected.CategoryName;
            }
            else
            {
                ClearForm();
            }
        }
        private void dgvCategories_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && dgvCategories.SelectedItem is Category selected)
            {
                string newName = selected.CategoryName.Trim();
                if (string.IsNullOrWhiteSpace(newName))
                {
                    MessageBox.Show("Category name cannot be empty.");
                    return;
                }

                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE ItemCategories SET CategoryName=@name WHERE CategoryID=@id", con);
                    cmd.Parameters.AddWithValue("@name", newName);
                    cmd.Parameters.AddWithValue("@id", selected.CategoryID);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Category updated via grid successfully.");
                        LoadCategories();
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 2627)
                            MessageBox.Show("This category already exists.");
                        else
                            MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.A)
            {
                btnAdd_Click(null, null);
                e.Handled = true;
            }
            if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.U)
            {
                btnUpdate_Click(null, null);
                e.Handled = true;
            }
            if (e.Key == Key.Delete)
            {
                btnDelete_Click(null, null);
                e.Handled = true;
            }

            base.OnPreviewKeyDown(e);
        }
    }
}
