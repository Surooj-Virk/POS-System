﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using POS_APP.DL;

namespace POS_APP.UI
{
	public partial class ReceiveStockFromVendor : Window
	{
		private List<ReceivedStockItem> receivedItems = new();

		public ReceiveStockFromVendor()
		{
			InitializeComponent();
			dateReceived.SelectedDate = DateTime.Today;
			LoadCategories();
			LoadVendors();
			vendorSection.Visibility = Visibility.Collapsed;

			dgvReceivedStock.SelectionChanged += DgvReceivedStock_SelectionChanged;
		}

		public class ReceivedStockItem
		{
			public string? Vendor { get; set; }
			public string? Category { get; set; }
			public string? Item { get; set; }
			public int Quantity { get; set; }
			public string? Unit { get; set; }
			public decimal Price { get; set; }
			public DateTime Date { get; set; }
		}

		private void LoadCategories()
		{
			var categories = new List<string>();

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				using SqlCommand cmd = new SqlCommand("SELECT CategoryName FROM ItemCategories ORDER BY CategoryName", con);
				using SqlDataReader reader = cmd.ExecuteReader();

				while (reader.Read())
				{
					string categoryName = reader["CategoryName"]?.ToString();
					if (!string.IsNullOrWhiteSpace(categoryName))
						categories.Add(categoryName);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading categories: " + ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}

			cmbCategory.ItemsSource = categories;
			cmbCategory.SelectedIndex = -1;
		}

		private void LoadVendors()
		{
			var vendors = new List<string>();

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				using SqlCommand cmd = new SqlCommand("SELECT DISTINCT Vendor FROM MenuItems WHERE Vendor IS NOT NULL", con);
				using SqlDataReader reader = cmd.ExecuteReader();

				while (reader.Read())
				{
					string vendorName = reader["Vendor"]?.ToString();
					if (!string.IsNullOrWhiteSpace(vendorName))
						vendors.Add(vendorName);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading vendors: " + ex.Message);
			}

			cmbVendors.ItemsSource = vendors;
		}

		private void chkFromVendor_Checked(object sender, RoutedEventArgs e)
		{
			if (chkFromCompany.IsChecked == true)
				chkFromCompany.IsChecked = false;

			vendorSection.Visibility = Visibility.Visible;
			cmbVendors.IsEnabled = true;
			txtNewVendor.IsEnabled = true;
		}

		private void chkFromVendor_Unchecked(object sender, RoutedEventArgs e)
		{
			if (chkFromCompany.IsChecked != true)
				vendorSection.Visibility = Visibility.Collapsed;
		}

		private void chkFromCompany_Checked(object sender, RoutedEventArgs e)
		{
			if (chkFromVendor.IsChecked == true)
				chkFromVendor.IsChecked = false;

			vendorSection.Visibility = Visibility.Collapsed;
			cmbVendors.IsEnabled = false;
			txtNewVendor.IsEnabled = false;
			cmbVendors.SelectedIndex = -1;
			txtNewVendor.Clear();
		}

		private void chkFromCompany_Unchecked(object sender, RoutedEventArgs e)
		{
			// No action needed
		}
		private void btnAdd_Click(object sender, RoutedEventArgs e)
		{
			if (!ValidateFormInputs(out int quantity, out decimal price))
				return;

			string vendor = GetVendorFromForm();
			if (string.IsNullOrEmpty(vendor))
				return;

			ReceivedStockItem newItem = new()
			{
				Vendor = vendor,
				Category = cmbCategory.SelectedItem.ToString(),
				Item = txtItem.Text.Trim(),
				Quantity = quantity,
				Unit = txtUnit.Text.Trim(),
				Price = price,
				Date = dateReceived.SelectedDate ?? DateTime.Today
			};

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				// ✅ Check if item already exists (by name and category)
				string checkQuery = @"SELECT MenuItemID, Quantity FROM MenuItems 
							  WHERE ItemName = @itemName AND Category = @category";
				using SqlCommand checkCmd = new SqlCommand(checkQuery, con);
				checkCmd.Parameters.AddWithValue("@itemName", newItem.Item);
				checkCmd.Parameters.AddWithValue("@category", newItem.Category);

				using SqlDataReader reader = checkCmd.ExecuteReader();

				if (reader.Read())
				{
					// ✅ Item exists → update quantity
					int existingItemId = reader.GetInt32(0);
					int existingQty = reader.GetInt32(1);
					reader.Close();

					string updateQuery = @"UPDATE MenuItems 
								   SET Quantity = Quantity + @qty, 
									   Price = @price,
									   Vendor = @vendor,
									   Unit = @unit,
									   DateReceived = @date
								   WHERE MenuItemID = @itemId";
					using SqlCommand updateCmd = new SqlCommand(updateQuery, con);
					updateCmd.Parameters.AddWithValue("@qty", newItem.Quantity);
					updateCmd.Parameters.AddWithValue("@price", newItem.Price);
					updateCmd.Parameters.AddWithValue("@vendor", newItem.Vendor ?? (object)DBNull.Value);
					updateCmd.Parameters.AddWithValue("@unit", newItem.Unit);
					updateCmd.Parameters.AddWithValue("@date", newItem.Date);
					updateCmd.Parameters.AddWithValue("@itemId", existingItemId);

					updateCmd.ExecuteNonQuery();

					// ✅ Update stock reconciliation
					OrderDL.AddPurchaseToStockReconciliation(existingItemId, newItem.Quantity);
				}
				else
				{
					reader.Close();

					// ❌ Item does not exist → insert new one
					string insertQuery = @"INSERT INTO MenuItems
			(ItemName, Category, Unit, Quantity, Price, Vendor, DateReceived)
			VALUES
			(@itemName, @category, @unit, @quantity, @price, @vendor, @date);
			SELECT SCOPE_IDENTITY();";

					using SqlCommand insertCmd = new SqlCommand(insertQuery, con);
					insertCmd.Parameters.AddWithValue("@itemName", newItem.Item);
					insertCmd.Parameters.AddWithValue("@category", newItem.Category);
					insertCmd.Parameters.AddWithValue("@unit", newItem.Unit);
					insertCmd.Parameters.AddWithValue("@quantity", newItem.Quantity);
					insertCmd.Parameters.AddWithValue("@price", newItem.Price);
					insertCmd.Parameters.AddWithValue("@vendor", newItem.Vendor ?? (object)DBNull.Value);
					insertCmd.Parameters.AddWithValue("@date", newItem.Date);

					object result = insertCmd.ExecuteScalar();
					if (result == null || !int.TryParse(result.ToString(), out int newItemId))
					{
						MessageBox.Show($"Failed to insert item '{newItem.Item}' or retrieve its ID.");
						return;
					}

					// ✅ Reconciliation for new item
					OrderDL.AddPurchaseToStockReconciliation(newItemId, newItem.Quantity);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error inserting or updating item: " + ex.Message);
				return;
			}

			receivedItems.Add(newItem);
			RefreshGrid();
			ClearForm();
			MessageBox.Show("Item saved successfully.");
		}

		private void btnUpdate_Click(object sender, RoutedEventArgs e)
		{
			if (dgvReceivedStock.SelectedItem is not ReceivedStockItem selectedItem)
			{
				MessageBox.Show("Please select an item to update.");
				return;
			}

			if (!ValidateFormInputs(out int newQuantity, out decimal price))
				return;

			string vendor = GetVendorFromForm();
			if (string.IsNullOrEmpty(vendor))
				return;

			selectedItem.Vendor = vendor;
			selectedItem.Category = cmbCategory.SelectedItem.ToString();
			selectedItem.Item = txtItem.Text.Trim();
			int oldQuantity = selectedItem.Quantity;  // save old quantity for reconciliation update
			selectedItem.Quantity = newQuantity;
			selectedItem.Unit = txtUnit.Text.Trim();
			selectedItem.Price = price;
			selectedItem.Date = dateReceived.SelectedDate ?? DateTime.Today;

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				// Get MenuItemID from DB
				int menuItemId = 0;
				using (SqlCommand getIdCmd = new SqlCommand("SELECT MenuItemID FROM MenuItems WHERE ItemName = @itemName", con))
				{
					getIdCmd.Parameters.AddWithValue("@itemName", selectedItem.Item);
					object idObj = getIdCmd.ExecuteScalar();
					if (idObj == null || !int.TryParse(idObj.ToString(), out menuItemId))
					{
						MessageBox.Show("Failed to get MenuItemID for the selected item.");
						return;
					}
				}

				using SqlTransaction transaction = con.BeginTransaction();

				string updateQuery = @"UPDATE MenuItems SET
			Category = @category,
			Unit = @unit,
			Quantity = @quantity,
			Price = @price,
			DateReceived = @date
			WHERE ItemName = @itemName";

				using SqlCommand updateCmd = new SqlCommand(updateQuery, con, transaction);
				updateCmd.Parameters.AddWithValue("@category", selectedItem.Category);
				updateCmd.Parameters.AddWithValue("@unit", selectedItem.Unit);
				updateCmd.Parameters.AddWithValue("@quantity", selectedItem.Quantity);
				updateCmd.Parameters.AddWithValue("@price", selectedItem.Price);
				updateCmd.Parameters.AddWithValue("@date", selectedItem.Date);
				updateCmd.Parameters.AddWithValue("@itemName", selectedItem.Item);

				int rowsAffected = updateCmd.ExecuteNonQuery();
				if (rowsAffected == 0)
				{
					MessageBox.Show("Failed to update item in database.");
					transaction.Rollback();
					return;
				}

				// Calculate quantity difference
				int quantityChange = newQuantity - oldQuantity;

				// Update stock reconciliation report accordingly
				OrderDL.UpdateStockReconciliationQuantity(menuItemId, quantityChange, transaction);

				transaction.Commit();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error updating item: " + ex.Message);
				return;
			}

			RefreshGrid();
			MessageBox.Show("Item updated successfully.");
			ClearForm();
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			if (dgvReceivedStock.SelectedItem is not ReceivedStockItem selectedItem)
			{
				MessageBox.Show("Please select an item to delete.");
				return;
			}

			var result = MessageBox.Show($"Are you sure you want to delete '{selectedItem.Item}'?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
			if (result != MessageBoxResult.Yes)
				return;

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				int menuItemId = 0;
				int oldQuantity = 0;

				// Get MenuItemID and current quantity for reconciliation update
				using (SqlCommand getCmd = new SqlCommand("SELECT MenuItemID, Quantity FROM MenuItems WHERE ItemName = @itemName", con))
				{
					getCmd.Parameters.AddWithValue("@itemName", selectedItem.Item);
					using SqlDataReader reader = getCmd.ExecuteReader();
					if (reader.Read())
					{
						menuItemId = reader.GetInt32(0);
						oldQuantity = reader.GetInt32(1);
					}
					else
					{
						MessageBox.Show("Failed to find item in database.");
						return;
					}
				}

				using SqlTransaction transaction = con.BeginTransaction();

				string deleteQuery = @"DELETE FROM MenuItems WHERE ItemName = @itemName";
				using SqlCommand deleteCmd = new SqlCommand(deleteQuery, con, transaction);
				deleteCmd.Parameters.AddWithValue("@itemName", selectedItem.Item);

				int rowsAffected = deleteCmd.ExecuteNonQuery();
				if (rowsAffected == 0)
				{
					MessageBox.Show("Failed to delete item from database.");
					transaction.Rollback();
					return;
				}

				// Subtract the old quantity from purchases in stock reconciliation
				OrderDL.UpdateStockReconciliationQuantity(menuItemId, -oldQuantity, transaction);

				transaction.Commit();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error deleting item: " + ex.Message);
				return;
			}

			receivedItems.Remove(selectedItem);
			RefreshGrid();
			MessageBox.Show("Item deleted successfully.");
			ClearForm();
		}

		private void DgvReceivedStock_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (dgvReceivedStock.SelectedItem is ReceivedStockItem selectedItem)
			{
				
				cmbCategory.SelectedItem = selectedItem.Category;
				txtItem.Text = selectedItem.Item;
				txtQuantity.Text = selectedItem.Quantity.ToString();
				txtUnit.Text = selectedItem.Unit;
				txtPrice.Text = selectedItem.Price.ToString("F2");
				dateReceived.SelectedDate = selectedItem.Date;

				if (selectedItem.Vendor == "Company")
				{
					chkFromCompany.IsChecked = true;
					chkFromVendor.IsChecked = false;
					vendorSection.Visibility = Visibility.Collapsed;
				}
				else
				{
					chkFromVendor.IsChecked = true;
					chkFromCompany.IsChecked = false;
					vendorSection.Visibility = Visibility.Visible;

					if (cmbVendors.ItemsSource is IEnumerable<string> vendors && vendors.Contains(selectedItem.Vendor))
					{
						cmbVendors.SelectedItem = selectedItem.Vendor;
						txtNewVendor.Clear();
					}
					else
					{
						cmbVendors.SelectedIndex = -1;
						txtNewVendor.Text = selectedItem.Vendor;
					}
				}
			}
		}

		private bool ValidateFormInputs(out int quantity, out decimal price)
		{
			quantity = 0;
			price = 0;

			if (cmbCategory.SelectedItem == null ||
			string.IsNullOrWhiteSpace(txtItem.Text) ||
			string.IsNullOrWhiteSpace(txtQuantity.Text) ||
			string.IsNullOrWhiteSpace(txtUnit.Text) ||
			string.IsNullOrWhiteSpace(txtPrice.Text))
			{
				MessageBox.Show("Category, Item, Quantity, Unit, and Price are required.");
				return false;
			}

			if (!int.TryParse(txtQuantity.Text, out quantity) || quantity <= 0)
			{
				MessageBox.Show("Enter a valid quantity.");
				return false;
			}

			if (!decimal.TryParse(txtPrice.Text, out price) || price <= 0)
			{
				MessageBox.Show("Enter a valid price.");
				return false;
			}

			return true;
		}

		private string GetVendorFromForm()
		{
			if (chkFromVendor.IsChecked == true)
			{
				string? vendor = !string.IsNullOrWhiteSpace(txtNewVendor.Text) ? txtNewVendor.Text.Trim() : cmbVendors.SelectedItem?.ToString();

				if (string.IsNullOrWhiteSpace(vendor))
				{
					MessageBox.Show("Please provide or select a vendor.");
					return null;
				}

				if (!string.IsNullOrWhiteSpace(txtNewVendor.Text))
				{
					var currentVendors = new List<string>();
					if (cmbVendors.ItemsSource is IEnumerable<string> existingVendors)
						currentVendors = new List<string>(existingVendors);

					string newVendor = txtNewVendor.Text.Trim();

					if (!currentVendors.Contains(newVendor, StringComparer.OrdinalIgnoreCase))
					{
						currentVendors.Add(newVendor);
						currentVendors.Sort(StringComparer.OrdinalIgnoreCase);
						cmbVendors.ItemsSource = null;
						cmbVendors.ItemsSource = currentVendors;
					}
				}
				return vendor;
			}
			else
			{
				return "Company";
			}
		}

		private void RefreshGrid()
		{
			dgvReceivedStock.ItemsSource = null;
			dgvReceivedStock.ItemsSource = receivedItems;
		}

		private void ClearForm()
		{
			txtNewVendor.Clear();
			cmbVendors.SelectedIndex = -1;
			cmbCategory.SelectedIndex = -1;
			txtItem.Clear();
			txtQuantity.Clear();
			txtUnit.Clear();
			txtPrice.Clear();
			dateReceived.SelectedDate = DateTime.Today;

			chkFromCompany.IsChecked = true;
			chkFromVendor.IsChecked = false;
			vendorSection.Visibility = Visibility.Collapsed;

			dgvReceivedStock.UnselectAll();
		}

		private void btnClear_Click(object sender, RoutedEventArgs e)
		{
			ClearForm();
		}
	}
}
