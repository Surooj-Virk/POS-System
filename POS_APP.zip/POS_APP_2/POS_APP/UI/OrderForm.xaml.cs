﻿using Microsoft.Win32;
using POS_APP.BL;
using POS_APP.DL;
using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace POS_APP.UI
{
	public partial class OrderForm : Window
	{

		private Dictionary<string, Tuple<int, decimal, string>> menuDict = new();
		private List<string> allMenuItems = new List<string>();
		private int _orderId = -1;
		private string invoiceContent = string.Empty;

		public OrderForm()
		{
			InitializeComponent();
			Loaded += OrderForm_Loaded;
			LoadMenuItems();
			dgvcarts.IsReadOnly = true;            // Keyboard shortcuts
		}

		private void OrderForm_Loaded(object sender, RoutedEventArgs e)
		{
			txtCustomerName.Focus();
			cmbPaymentMethod.SelectedIndex = 0;
			//richInvoice.Document.Blocks.Clear();
			LoadMenuItems();

		}
		// In OrderForm.xaml.cs
		// ✅ This is already the correct place to use:
		// var validItems = StockReconciliationDL.GetItemsWithStockAvailable(today);

		private void LoadMenuItems()
		{
			try
			{
				cmbitems.Items.Clear();
				menuDict.Clear();
				allMenuItems.Clear();

				// ✅ This line is correct and must stay as-is:
				DateTime today = DateTime.Today;
				var validItems = StockReconciliationDL.GetItemsWithStockAvailable(today);

				var addedNames = new HashSet<string>();

				foreach (var item in validItems)
				{
					if (!string.IsNullOrWhiteSpace(item.Item) && addedNames.Add(item.Item))
					{
						allMenuItems.Add(item.Item);
						menuDict[item.Item] = Tuple.Create(item.MenuItemID, item.Price, item.Category);
					}
				}

				cmbitems.ItemsSource = allMenuItems;
				UpdateStatus("Menu items loaded successfully.");
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Failed to load menu: {ex.Message}");
				UpdateStatus("Error loading menu items.");
			}
		}


		private void ADD_Click(object sender, RoutedEventArgs e)
		{
			if (cmbitems.SelectedItem == null || cmbPaymentMethod.SelectedItem == null)
			{
				MessageBox.Show("Please select an item and payment method.");
				return;
			}

			string? name = cmbitems.SelectedItem.ToString();
			int quantity = int.TryParse(numqnt.Text, out int q) ? q : 1;

			if (!menuDict.TryGetValue(name, out var item)) return;

			int id = item.Item1;
			decimal price = item.Item2;
			string? category = item.Item3;

			var selectedItem = MenuItemDL.GetAllItems().FirstOrDefault(x => x.MenuItemID == id);

			if (selectedItem == null)
			{
				MessageBox.Show("Selected item not found in stock.");
				return;
			}

			if (selectedItem.Quantity == 0)
			{
				MessageBox.Show("Selected item is out of stock.");
				LoadMenuItems(); // Refresh the item list to exclude zero stock items
				return;
			}

			// Find if the item is already in the order
			var existingOrderItem = OrderBL.CurrentOrder.FirstOrDefault(x => x.MenuItemID == id);

			if (existingOrderItem != null)
			{
				// Calculate new quantity
				int newQuantity = existingOrderItem.Quantity + quantity;

				if (newQuantity > selectedItem.Quantity)
				{
					MessageBox.Show($"Only {selectedItem.Quantity} items left in stock.");
					return;
				}

				// Update quantity
				existingOrderItem.Quantity = newQuantity;
			}
			else
			{
				// Check if requested quantity is available
				if (quantity > selectedItem.Quantity)
				{
					MessageBox.Show($"Only {selectedItem.Quantity} items left in stock.");
					return;
				}

				// Add new item
				string result = OrderBL.AddOrderItem(id, name, category, price, quantity);
				MessageBox.Show(result);
			}

			RefreshCart();

			// Set focus back to the ComboBox and open dropdown
			cmbitems.Focus();
			cmbitems.IsDropDownOpen = true;

			// Optional: Clear the selection to prepare for new item
			cmbitems.SelectedItem = null;
			cmbitems.Text = string.Empty;

			// Optional: Reset quantity to 1
			numqnt.Text = "1";
		}
		private void RefreshCart()
		{
			try
			{
				var displayItems = OrderBL.CurrentOrder.Select((item, index) => new OrderItem
				{
					MenuItemID = item.MenuItemID,
					SrNo = index + 1,
					Category = item.Category,
					ItemName = item.ItemName,
					Quantity = item.Quantity,
					UnitPrice = item.UnitPrice
				}).ToList();

				dgvcarts.ItemsSource = null;
				dgvcarts.ItemsSource = displayItems;

				decimal total = displayItems.Sum(x => x.Total);
				decimal discount = decimal.TryParse(txtDiscount.Text, out decimal d) ? d : 0;
				decimal finalTotal = total - discount;

				lblTotal.Content = $"Total: Rs. {total:N2}\nDiscount: Rs. {discount:N2}\nFinal Total: Rs. {finalTotal:N2}";

				UpdateStatus("Cart updated.");
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Cart update failed: {ex.Message}");
				UpdateStatus("Cart refresh error.");
			}
		}

		private void RemoveSelectedItem_Click(object sender, RoutedEventArgs e)
		{
			if (dgvcarts.SelectedItem is OrderItem selected)
			{
				var toRemove = OrderBL.CurrentOrder.FirstOrDefault(x => x.ItemName == selected.ItemName && x.UnitPrice == selected.UnitPrice);
				if (toRemove != null)
				{
					OrderBL.CurrentOrder.Remove(toRemove);
					RefreshCart();
				}
			}
		}

		//private void PlaceOrder_Click(object sender, RoutedEventArgs e)
		//{
		//    if (!ValidateOrderInputs()) return;

		//    string customerName = txtCustomerName.Text.Trim();
		//    string customerPhone = txtCustomerPhone.Text.Trim();
		//    string paymentMethod = (cmbPaymentMethod.SelectedItem as ComboBoxItem)?.Content.ToString();

		//    // Place the order and get the order ID
		//    int newOrderId = OrderBL.PlaceOrder(Signin.Session.UserId, paymentMethod, out string msg);

		//    if (newOrderId == -1)
		//    {
		//        MessageBox.Show(msg);
		//        return;
		//    }

		//    // Store the order ID in the field
		//    _orderId = newOrderId;

		//    // Generate and display invoice
		//    DisplayInvoiceWithImageLogo(_orderId, customerName, customerPhone, paymentMethod);
		//    MessageBox.Show($"Order #{_orderId} placed successfully.");

		//    // Print the invoice immediately
		//    PrintInvoice(_orderId, customerName, customerPhone, paymentMethod);

		//    // Clear current order and refresh UI (but keep _orderId for any reprints)
		//    OrderBL.CurrentOrder.Clear();
		//    RefreshCart();
		//}



		//private void PlaceOrder_Click(object sender, RoutedEventArgs e)
		//{
		//    if (!ValidateOrderInputs()) return;

		//    string customerName = txtCustomerName.Text.Trim();
		//    string customerPhone = txtCustomerPhone.Text.Trim();
		//    string customerAddress = txtCustomerAddress.Text.Trim();
		//    string paymentMethod = (cmbPaymentMethod.SelectedItem as ComboBoxItem)?.Content.ToString();

		//    // Get discount value
		//    decimal discount = decimal.TryParse(txtDiscount.Text, out decimal d) ? d : 0;

		//    // Place the order (discount passed for invoice only)
		//    int newOrderId = OrderBL.PlaceOrder(Signin.Session.UserId, paymentMethod, out string msg);

		//    if (newOrderId == -1)
		//    {
		//        MessageBox.Show(msg);
		//        return;
		//    }

		//    _orderId = newOrderId;

		//    // Generate invoice with discount
		//    string invoiceText = InvoiceBL.GenerateInvoiceText(_orderId, customerName, customerAddress, customerPhone, paymentMethod, discount);

		//    var previewWindow = new InvoicePreviewWindow(_orderId, invoiceText);
		//    previewWindow.ShowDialog();

		//    OrderBL.CurrentOrder.Clear();
		//    RefreshCart();
		//    MessageBox.Show($"Order #{_orderId} placed successfully with discount of Rs. {discount}");
		//}
		private void PlaceOrder_Click(object sender, RoutedEventArgs e)
		{
			if (!ValidateOrderInputs()) return;

			string? customerName = txtCustomerName.Text.Trim();
			string? customerPhone = txtCustomerPhone.Text.Trim();
			string? customerAddress = txtCustomerAddress.Text.Trim();
			string? paymentMethod = (cmbPaymentMethod.SelectedItem as ComboBoxItem)?.Content.ToString();
			decimal discount = decimal.TryParse(txtDiscount.Text, out decimal d) ? d : 0;

			int newOrderId = OrderBL.PlaceOrder(Signin.Session.UserId, paymentMethod, discount, out string msg);

			if (newOrderId == -1)
			{
				MessageBox.Show(msg);
				return;
			}

			_orderId = newOrderId;

			// Update stock reconciliation and stock quantities for this sale
			OrderDL.UpdateStockReconciliationAfterSale(_orderId);

			// Print the invoice immediately
			PrintInvoice(_orderId, customerName, customerPhone, customerAddress, paymentMethod, discount);

			// Show preview (optional)
			string invoiceText = InvoiceBL.GenerateInvoiceText(_orderId, customerName, customerAddress, customerPhone, paymentMethod, discount);
			var previewWindow = new InvoicePreviewWindow(_orderId, invoiceText);
			previewWindow.ShowDialog();

			OrderBL.CurrentOrder.Clear();
			RefreshCart();
			MessageBox.Show($"Order #{_orderId} placed successfully. Discount: Rs. {discount:N2}");
		}


		private void PrintInvoice(int orderId, string customerName, string customerPhone, string customerAddress, string paymentMethod, decimal discount)
		{
			try
			{
				PrintDialog printDialog = new PrintDialog();

				// Set dimensions for 80mm wide paper (72.1mm is the printable area)
				double pageWidthInMM = 72.1; // Printable area width
				double pageHeightInMM = 297; // Standard length (can be adjusted)
				double mmToInch = 0.0393701;
				double dpi = 96;

				double pageWidth = pageWidthInMM * mmToInch * dpi;
				double pageHeight = pageHeightInMM * mmToInch * dpi;

				FixedDocument document = new FixedDocument();
				document.DocumentPaginator.PageSize = new Size(pageWidth, pageHeight);

				FixedPage page = new FixedPage();
				page.Width = pageWidth;
				page.Height = pageHeight;

				// Generate invoice text with discount
				string invoiceText = InvoiceBL.GenerateInvoiceText(
					orderId,
					customerName,
					customerAddress,
					customerPhone,
					paymentMethod,
					discount
				);

				TextBlock textBlock = new TextBlock
				{
					Text = invoiceText,
					FontFamily = new FontFamily("Courier New"),
					FontSize = 10,
					TextWrapping = TextWrapping.Wrap,
					Width = pageWidth - 10, // Leave small margins
					Margin = new Thickness(5)
				};

				page.Children.Add(textBlock);
				PageContent pageContent = new PageContent();
				((IAddChild)pageContent).AddChild(page);
				document.Pages.Add(pageContent);

				if (printDialog.ShowDialog() == true)
				{
					printDialog.PrintDocument(document.DocumentPaginator, $"Invoice #{orderId}");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Printing error: {ex.Message}");
			}
		}

		private bool ValidateOrderInputs()
		{
			if (!OrderBL.CurrentOrder.Any())
			{
				MessageBox.Show("No items in cart.");
				return false;
			}

			if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
			{
				MessageBox.Show("Customer name required.");
				return false;
			}

			// Add discount validation
			if (!decimal.TryParse(txtDiscount.Text, out decimal discount))
			{
				MessageBox.Show("Please enter a valid discount amount.");
				return false;
			}

			decimal total = OrderBL.CurrentOrder.Sum(x => x.Total);
			if (discount > total)
			{
				MessageBox.Show("Discount cannot be greater than total amount.");
				return false;
			}

			return true;
		}

		private void DisplayInvoiceWithImageLogo(int orderId, string customerName, string customerPhone, string paymentMethod)
		{
			//richInvoice.Document = GenerateInvoiceDocument(orderId, customerName, customerPhone, paymentMethod);
			//richInvoice.Visibility = Visibility.Visible;
		}

		private FlowDocument GenerateInvoiceDocument(int orderId, string customerName, string customerAddress, string customerPhone, string paymentMethod)
		{
			invoiceContent = InvoiceBL.GenerateInvoiceText(orderId, customerName, customerAddress, customerPhone, paymentMethod);

			var doc = new FlowDocument
			{
				FontFamily = new FontFamily("Courier New"),
				FontSize = 12,
				PagePadding = new Thickness(15),
				TextAlignment = TextAlignment.Left,
				LineHeight = 12,
				PageWidth = 900 // <-- Add this line
			};

			var header = new Paragraph();
			try
			{
				var logo = new Image
				{
					Source = new BitmapImage(new Uri("pack://application:,,,/Resources/pizza_albaik.PNG")),
					Width = 150,
					Height = 150,
					Stretch = Stretch.Uniform
				};
				header.Inlines.Add(logo);
			}
			catch
			{
				header.Inlines.Add(new Run("PIZZA ALBAIK") { FontSize = 20, FontWeight = FontWeights.Bold });
			}

			header.Inlines.Add(new LineBreak());
			header.Inlines.Add(new Run("Shop no 4, phase 1\nnasheman-e-iqbal cooperative\nhousing society Lahore\nPh: 03096081702, 03096081715\nHome Delivery Available"));

			doc.Blocks.Add(header);

			var invoicePara = new Paragraph(new Run(invoiceContent));
			doc.Blocks.Add(invoicePara);

			return doc;
		}

		private FlowDocument CreatePrintableDocument()
		{
			var doc = new FlowDocument
			{
				FontFamily = new FontFamily("Courier New"),
				FontSize = 11.5,
				PagePadding = new Thickness(20),
				ColumnWidth = double.PositiveInfinity,
				TextAlignment = TextAlignment.Left
			};

			string? invoiceText = InvoiceBL.GenerateInvoiceText(
				_orderId,
				txtCustomerName.Text.Trim(),
				txtCustomerPhone.Text.Trim(),
				txtCustomerAddress.Text.Trim(),
				(cmbPaymentMethod.SelectedItem as ComboBoxItem)?.Content.ToString()
			);

			// Use max 48 characters per line for thermal printers
			foreach (string line in invoiceText.Split('\n'))
			{
				if (string.IsNullOrWhiteSpace(line)) continue;

				var para = new Paragraph { Margin = new Thickness(0), LineHeight = 14 };

				if (line.Contains("***********************************") || line.Contains("-----------------------------------------------------------"))
				{
					para.Inlines.Add(new Run(line.Trim().Substring(0, Math.Min(48, line.Length))) { FontWeight = FontWeights.Bold });
				}
				else if (line.Contains("INVOICE") || line.Contains("Thank you") || line.Contains("POWERED BY"))
				{
					para.TextAlignment = TextAlignment.Center;
					para.Inlines.Add(new Run(line.Trim()) { FontWeight = FontWeights.Bold });
				}
				else if (line.StartsWith("Order ID:") || line.StartsWith("Date:") || line.StartsWith("Customer:") || line.StartsWith("Phone:") || line.StartsWith("Payment:"))
				{
					para.Inlines.Add(new Run(line));
				}
				else if (line.StartsWith("#") || line.StartsWith("1") || line.StartsWith("2"))
				{
					// Format item rows with tabs if needed
					para.Inlines.Add(new Run(line));
				}
				else if (line.StartsWith("GRAND TOTAL:"))
				{
					para.TextAlignment = TextAlignment.Right;
					para.Inlines.Add(new Run(line.Trim()) { FontWeight = FontWeights.Bold });
				}
				else
				{
					para.Inlines.Add(new Run(line.Trim()));
				}

				doc.Blocks.Add(para);
			}

			doc.PageWidth = 6.0 * 96;   // ~6 inches
			doc.PageHeight = 11 * 96;

			return doc;
		}

		private void Print_Click(object sender, RoutedEventArgs e)
		{
			var printDialog = new PrintDialog();
			if (printDialog.ShowDialog() == true)
			{
				var doc = CreatePrintableDocument();
				printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Invoice");
			}
		}
		private void IncreaseQuantity_Click(object sender, RoutedEventArgs e)
		{
			if (int.TryParse(numqnt.Text, out int qty))
				numqnt.Text = (qty + 1).ToString();
		}

		private void DecreaseQuantity_Click(object sender, RoutedEventArgs e)
		{
			if (int.TryParse(numqnt.Text, out int qty) && qty > 1)
				numqnt.Text = (qty - 1).ToString();
		}

		private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !int.TryParse(e.Text, out _);
		}

		private void UpdateStatus(string message)
		{
			if (txtStatus != null)
				txtStatus.Text = message;
		}

		//private void cmbitems_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

		private void dgvcarts_SelectionChanged(object sender, SelectionChangedEventArgs e) { }


		private void cmbitems_KeyUp(object sender, KeyEventArgs e)
		{
			if (sender is ComboBox comboBox && comboBox.IsEditable)
			{
				var textBox = comboBox.Template.FindName("PART_EditableTextBox", comboBox) as TextBox;
				if (textBox == null) return;

				string searchText = textBox.Text.ToLower();
				int caretPosition = textBox.CaretIndex;

				if (e.Key == Key.Enter)
				{
					if (comboBox.SelectedItem != null)
					{
						numqnt.Focus(); // Move to quantity box
					}
					else if (comboBox.Items.Count > 0)
					{
						comboBox.SelectedItem = comboBox.Items[0];
						numqnt.Focus();
					}
					e.Handled = true;
					return;
				}

				// Safe check in case allMenuItems is null or empty
				if (allMenuItems == null || allMenuItems.Count == 0)
				{
					return;
				}

				// Filtering logic
				if (string.IsNullOrWhiteSpace(searchText))
				{
					comboBox.ItemsSource = allMenuItems;
					comboBox.IsDropDownOpen = true;
					return;
				}

				var filteredItems = allMenuItems
					.Where(item => item.ToLower().Contains(searchText))
					.ToList();

				comboBox.ItemsSource = filteredItems;
				comboBox.IsDropDownOpen = filteredItems.Any();
				textBox.CaretIndex = caretPosition;
			}
		}

		private void cmbitems_GotFocus(object sender, RoutedEventArgs e)
		{
			if (sender is ComboBox comboBox)
			{
				comboBox.IsDropDownOpen = true;
			}
		}

		private void cmbitems_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (cmbitems.SelectedItem != null)
			{
				numqnt.Focus();         // Automatically move to quantity
				numqnt.SelectAll();     // Let user enter quantity directly
			}
		}

	}

}
