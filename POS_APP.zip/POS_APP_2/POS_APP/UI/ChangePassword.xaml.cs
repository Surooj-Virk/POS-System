﻿using Microsoft.Data.SqlClient;
using POS_APP.DL;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace POS_APP.UI
{
    public partial class ChangePassword : Window
    {
        public ChangePassword()
        {
            InitializeComponent();
            InitializePlaceholders();
            this.Focusable = true;

        }

        private void InitializePlaceholders()
        {
            // Set initial placeholder values
            txtCurrentUsername.Tag = "Current Username";
            txtCurrentPassword.Tag = "Current Password";
            txtNewUsername.Tag = "New Username";
            txtNewPassword.Tag = "New Password";

            txtCurrentUsername.Text = (string)txtCurrentUsername.Tag;
            txtCurrentUsername.Foreground = Brushes.Gray;

            txtNewUsername.Text = (string)txtNewUsername.Tag;
            txtNewUsername.Foreground = Brushes.Gray;
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && string.IsNullOrWhiteSpace(textBox.Text))
            {
                if (textBox.Name == "txtCurrentUsername")
                    textBox.Text = (string)txtCurrentUsername.Tag;
                else if (textBox.Name == "txtNewUsername")
                    textBox.Text = (string)txtNewUsername.Tag;

                textBox.Foreground = Brushes.Gray;
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox passwordBox)
            {
                var placeholder = FindPlaceholder(passwordBox);
                placeholder?.SetCurrentValue(VisibilityProperty, Visibility.Collapsed);
            }
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox passwordBox)
            {
                var placeholder = FindPlaceholder(passwordBox);
                if (placeholder != null && string.IsNullOrEmpty(passwordBox.Password))
                {
                    placeholder.Visibility = Visibility.Visible;
                }
            }
        }

        private TextBlock FindPlaceholder(PasswordBox passwordBox)
        {
            return passwordBox.Name switch
            {
                "txtCurrentPassword" => txtCurrentPasswordPlaceholder,
                "txtNewPassword" => txtNewPasswordPlaceholder,
                _ => null
            };
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string currentUsername = txtCurrentUsername.Foreground == Brushes.Gray ? "" : txtCurrentUsername.Text;
            string currentPassword = txtCurrentPasswordPlaceholder.Visibility == Visibility.Visible ? "" : txtCurrentPassword.Password;
            string newUsername = txtNewUsername.Foreground == Brushes.Gray ? "" : txtNewUsername.Text;
            string newPassword = txtNewPasswordPlaceholder.Visibility == Visibility.Visible ? "" : txtNewPassword.Password;
            if (newUsername.Contains("'") || newUsername.Contains(";") ||
    currentUsername.Contains("'") || currentUsername.Contains(";"))
            {
                MessageBox.Show("Username cannot contain special characters", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            // Validation
            if (string.IsNullOrWhiteSpace(currentUsername) || string.IsNullOrWhiteSpace(currentPassword))
            {
                MessageBox.Show("Current username and password are required.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(newUsername) && string.IsNullOrWhiteSpace(newPassword))
            {
                MessageBox.Show("Please enter a new username or password to update.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();

                    // Verify current credentials
                    string checkQuery = "SELECT COUNT(1) FROM Users WHERE Username = @u AND Password = @p AND Role = 'Admin'";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
                    {
                        checkCmd.Parameters.AddWithValue("@u", currentUsername);
                        checkCmd.Parameters.AddWithValue("@p", currentPassword);

                        if ((int)checkCmd.ExecuteScalar() == 0)
                        {
                            MessageBox.Show("Incorrect current credentials.", "Authentication Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }

                    // Build dynamic update query
                    var updates = new System.Text.StringBuilder("UPDATE Users SET ");
                    var parameters = new System.Collections.Generic.List<SqlParameter>();

                    if (!string.IsNullOrWhiteSpace(newUsername))
                    {
                        if (newUsername == currentUsername)
                        {
                            MessageBox.Show("New username cannot be the same as current username.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                        updates.Append("Username = @newU");
                        parameters.Add(new SqlParameter("@newU", newUsername));
                    }

                    if (!string.IsNullOrWhiteSpace(newPassword))
                    {
                        if (newPassword == currentPassword)
                        {
                            MessageBox.Show("New password cannot be the same as current password.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                        if (parameters.Count > 0) updates.Append(", ");
                        updates.Append("Password = @newP");
                        parameters.Add(new SqlParameter("@newP", newPassword));
                    }

                    updates.Append(" WHERE Username = @u AND Password = @p");
                    parameters.Add(new SqlParameter("@u", currentUsername));
                    parameters.Add(new SqlParameter("@p", currentPassword));

                    using (SqlCommand updateCmd = new SqlCommand(updates.ToString(), con))
                    {
                        updateCmd.Parameters.AddRange(parameters.ToArray());
                        int affectedRows = updateCmd.ExecuteNonQuery();

                        if (affectedRows > 0)
                        {
                            MessageBox.Show("Credentials updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Update failed. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // F5 shortcut for Update button (works anywhere in window)
            if (e.Key == Key.F5)
            {
                btnUpdate.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                e.Handled = true;
                return;
            }

            // Alternative: Ctrl+Enter shortcut
            if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control)
            {
                btnUpdate.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                e.Handled = true;
            }
        }
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            // F5 shortcut - works anywhere in window
            if (e.Key == Key.F5)
            {
                btnUpdate_Click(null, null);
                e.Handled = true;
            }

            // Alternative: Ctrl+Enter shortcut
            if (e.Key == Key.Enter &&
               (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)))
            {
                btnUpdate_Click(null, null);
                e.Handled = true;
            }
        }


    }
}