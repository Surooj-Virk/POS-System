﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using POS_APP.DL;

namespace POS_APP.UI
{
    public partial class AddExpenseCategory : Window
    {
        private int selectedCategoryId = -1;

        public AddExpenseCategory()
        {
            InitializeComponent();
            LoadCategories();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCategories();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            string category = txtCategoryName.Text.Trim();
            if (string.IsNullOrEmpty(category))
            {
                MessageBox.Show("Please enter a category.");
                return;
            }

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                // Check for duplicate
                string checkQuery = "SELECT COUNT(*) FROM ExpenseCategory WHERE CategoryName = @name";
                SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                checkCmd.Parameters.AddWithValue("@name", category);
                con.Open();
                int count = (int)checkCmd.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("This category already exists.");
                    con.Close();
                    return;
                }

                // Insert if not duplicate
                string insertQuery = "INSERT INTO ExpenseCategory (CategoryName) VALUES (@name)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                insertCmd.Parameters.AddWithValue("@name", category);
                insertCmd.ExecuteNonQuery();
                con.Close();
            }

            MessageBox.Show("Category added!");
            txtCategoryName.Clear();
            selectedCategoryId = -1;
            LoadCategories();
        }


        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category to update.");
                return;
            }

            string newName = txtCategoryName.Text.Trim();
            if (string.IsNullOrEmpty(newName))
            {
                MessageBox.Show("Please enter a new name.");
                return;
            }

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "UPDATE ExpenseCategory SET CategoryName = @name WHERE ID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", newName);
                cmd.Parameters.AddWithValue("@id", selectedCategoryId);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            MessageBox.Show("Category updated.");
            txtCategoryName.Clear();
            selectedCategoryId = -1;
            LoadCategories();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category to delete.");
                return;
            }

            var result = MessageBox.Show("Are you sure you want to delete this category?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.No)
                return;

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "DELETE FROM ExpenseCategory WHERE ID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedCategoryId);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            MessageBox.Show("Category deleted.");
            txtCategoryName.Clear();
            selectedCategoryId = -1;
            LoadCategories();
        }

        private void dgvCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvCategories.SelectedItem is DataRowView row)
            {
                txtCategoryName.Text = row["CategoryName"].ToString();
                selectedCategoryId = Convert.ToInt32(row["ID"]);
            }
        }

        private void LoadCategories()
        {
            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "SELECT * FROM ExpenseCategory";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCategories.ItemsSource = dt.DefaultView;

                if (dgvCategories.Columns.Count > 0 && dgvCategories.Columns[0].Header.ToString() == "ID")
                {
                    dgvCategories.Columns[0].Visibility = Visibility.Collapsed;
                }
            }
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyboardDevice.Modifiers == ModifierKeys.Control && e.Key == Key.A)
            {
                btnView_Click(null, null);
                e.Handled = true;
            }
        }
    }
}
