﻿using Microsoft.Data.SqlClient;
using POS_APP.DL;
using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace POS_APP.UI
{
    public partial class AdminApproval : Window
    {
        private List<string> roleOptions = new List<string> { "Admin", "Cashier" };

        public AdminApproval()
        {
            InitializeComponent();
            dgPendingUsers.LoadingRow += DgPendingUsers_LoadingRow;
            LoadPendingUsers();
        }

        private void DgPendingUsers_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            var comboColumn = dgPendingUsers.Columns
                .OfType<DataGridComboBoxColumn>()
                .FirstOrDefault();

            if (comboColumn != null && comboColumn.ItemsSource == null)
            {
                comboColumn.ItemsSource = roleOptions;
            }
        }

        private void LoadPendingUsers()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();
                    string query = "SELECT UserID, Username, Role FROM Users WHERE IsApproved = 0";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    List<UserModel> users = new List<UserModel>();
                    while (reader.Read())
                    {
                        users.Add(new UserModel
                        {
                            UserID = Convert.ToInt32(reader["UserID"]),
                            Username = reader["Username"].ToString(),
                            Role = reader["Role"].ToString()
                        });
                    }

                    dgPendingUsers.ItemsSource = users;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading pending users: {ex.Message}");
            }
        }

        private void btnApprove_Click(object sender, RoutedEventArgs e)
        {
            if (dgPendingUsers.SelectedItem == null)
            {
                MessageBox.Show("Please select a user to approve.");
                return;
            }

            try
            {
                var selectedUser = (UserModel)dgPendingUsers.SelectedItem;

                using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                {
                    con.Open();
                    string query = "UPDATE Users SET IsApproved = 1, Role = @role WHERE UserID = @userId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@userId", selectedUser.UserID);
                    cmd.Parameters.AddWithValue("@role", selectedUser.Role);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("User approved successfully!");
                        LoadPendingUsers();
                    }
                    else
                    {
                        MessageBox.Show("Failed to approve user.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error approving user: {ex.Message}");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgPendingUsers.SelectedItem == null)
            {
                MessageBox.Show("Please select a user to delete.");
                return;
            }

            var selectedUser = (UserModel)dgPendingUsers.SelectedItem;

            if (MessageBox.Show("Are you sure you want to delete this user request?", "Confirm Delete",
                MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
                    {
                        con.Open();
                        string query = "DELETE FROM Users WHERE UserID = @userId";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@userId", selectedUser.UserID);

                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("User request deleted successfully!");
                            LoadPendingUsers();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete user request.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting user: {ex.Message}");
                }
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadPendingUsers();
        }
    }
}
