﻿using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POS_APP.DL;


namespace POS_APP.BL
{
    class SalesBL
    {
        public static List<SalesReport> GetSalesReport(DateTime from, DateTime to)
        {
            return SalesDL.GetSalesReport(from, to);
        }
    }
}
