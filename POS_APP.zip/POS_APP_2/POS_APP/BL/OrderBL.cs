﻿using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using POS_APP.DL;
using Microsoft.Data.SqlClient;

namespace POS_APP.BL
{
	class OrderBL
	{
		public static List<OrderItem> CurrentOrder = new List<OrderItem>();

		public static string AddOrderItem(int menuItemId, string? name, string? category, decimal price, int qty)
		{
			if (qty <= 0)
				return "Quantity must be greater than 0.";

			OrderItem? existing = CurrentOrder.Find(x => x.MenuItemID == menuItemId);
			if (existing != null)
			{
				// Use existing safely
				existing.Quantity += qty;
			}
			else
			{
				// Add as new item, with full details
				CurrentOrder.Add(new OrderItem
				{
					MenuItemID = menuItemId,
					ItemName = name,
					Category = category,
					UnitPrice = price,
					Quantity = qty
				});
			}

			return "Item added successfully.";
		}

		public static int PlaceOrder(int userId, string paymentMethod, decimal discount, out string message)
		{
			message = "";
			int newOrderId = -1;

			try
			{
				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				using SqlTransaction transaction = con.BeginTransaction();
				try
				{
					// Step 1: Calculate totals
					decimal total = CurrentOrder.Sum(item => item.Quantity * item.UnitPrice);
					decimal finalAmount = total - discount;

					// Step 2: Insert into Orders and get new OrderID
					SqlCommand cmd = new SqlCommand(@"
				INSERT INTO Orders (UserID, PaymentMethod, Discount, FinalAmount, TotalAmount)
				OUTPUT INSERTED.OrderID
				VALUES (@userId, @paymentMethod, @discount, @finalAmount, @totalAmount)", con, transaction);

					cmd.Parameters.AddWithValue("@userId", userId);
					cmd.Parameters.AddWithValue("@paymentMethod", paymentMethod);
					cmd.Parameters.AddWithValue("@discount", discount);
					cmd.Parameters.AddWithValue("@finalAmount", finalAmount);
					cmd.Parameters.AddWithValue("@totalAmount", total);

					// Get the inserted Order ID
					newOrderId = Convert.ToInt32(cmd.ExecuteScalar());

					// Step 3: Insert OrderDetails
					foreach (var item in CurrentOrder)
					{
						SqlCommand detailCmd = new SqlCommand(@"
					INSERT INTO OrderDetails (OrderID, MenuItemID, Quantity, UnitPrice)
					VALUES (@orderId, @menuItemId, @quantity, @unitPrice)", con, transaction);

						detailCmd.Parameters.AddWithValue("@orderId", newOrderId);
						detailCmd.Parameters.AddWithValue("@menuItemId", item.MenuItemID);
						detailCmd.Parameters.AddWithValue("@quantity", item.Quantity);
						detailCmd.Parameters.AddWithValue("@unitPrice", item.UnitPrice);

						detailCmd.ExecuteNonQuery();
					}

					// Step 4: Commit
					transaction.Commit();
					message = "Order placed successfully.";
				}
				catch (Exception ex)
				{
					transaction.Rollback();
					message = $"Error placing order: {ex.Message}";
				}
			}
			catch (Exception ex)
			{
				message = $"Database error: {ex.Message}";
			}

			return newOrderId;
		}
		// New method to update stock quantities and insert sales records after order placement
		public static bool UpdateStockAndSales(int orderId)
		{
			using (var con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				using (var transaction = con.BeginTransaction())
				{
					try
					{
						foreach (var item in CurrentOrder)
						{
							var updateStockCmd = new SqlCommand(
								"UPDATE MenuItems SET Quantity = Quantity - @qty WHERE MenuItemID = @itemId AND Quantity >= @qty",
								con, transaction);
							updateStockCmd.Parameters.AddWithValue("@qty", item.Quantity);
							updateStockCmd.Parameters.AddWithValue("@itemId", item.MenuItemID);

							int rowsAffected = updateStockCmd.ExecuteNonQuery();

							if (rowsAffected == 0)
							{
								throw new Exception($"Insufficient stock for item ID {item.MenuItemID}.");
							}

							var insertSalesCmd = new SqlCommand(
								"INSERT INTO Sales (MenuItemID, QuantitySold, SaleDate, OrderID) VALUES (@itemId, @qty, @date, @orderId)",
								con, transaction);
							insertSalesCmd.Parameters.AddWithValue("@itemId", item.MenuItemID);
							insertSalesCmd.Parameters.AddWithValue("@qty", item.Quantity);
							insertSalesCmd.Parameters.AddWithValue("@date", DateTime.Now);
							insertSalesCmd.Parameters.AddWithValue("@orderId", orderId);

							insertSalesCmd.ExecuteNonQuery();
						}

						transaction.Commit();
						return true;  // success
					}
					catch
					{
						transaction.Rollback();
						return false;  // failure
					}
				}
			}
		}
	}
}
