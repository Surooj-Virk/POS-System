﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POS_APP.Models;

namespace POS_APP.BL
{
	class MenuItemBL
	{
		public string ValidateMenuItem(ReceivedStockItem item)
		{
			if (string.IsNullOrWhiteSpace(item.Item))
				return "Item name is required.";

			if (item.Price <= 0)
				return "Price must be greater than zero.";

			if (string.IsNullOrWhiteSpace(item.Category))
				return "Category is required.";

			return string.Empty;
		}
	}
}
