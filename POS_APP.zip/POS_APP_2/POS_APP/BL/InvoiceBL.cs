﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using POS_APP.DL;

namespace POS_APP.BL
{
    class InvoiceBL
    {
       
        public static string GenerateInvoiceText(int orderId, string customerName, string customerAddress, string customerPhone, string paymentMethod, decimal discount = 0)
        {
            var items = InvoiceDL.GetInvoiceItems(orderId);
            var sb = new StringBuilder();

            // Column widths
            const int totalWidth = 43;
            const int colSrNo = 2;
            const int colItem = 20;
            const int colQty = 3;
            const int colRate = 5;   // for "UnitP"
            const int colTotal = 5;  // for "Total"

            // Header
            sb.AppendLine(CenterText("PIZZA ALBAIK", totalWidth));
            sb.AppendLine(CenterText("Shop no 4, phase 1", totalWidth));
            sb.AppendLine(CenterText("Nasheman-e-Iqbal Cooperative", totalWidth));
            sb.AppendLine(CenterText("Lahore", totalWidth));
            sb.AppendLine(CenterText("Ph: 03096081702, 03096081715", totalWidth));
            sb.AppendLine();

            // Invoice Title
            sb.AppendLine(new string('*', totalWidth));
            sb.AppendLine(CenterText("INVOICE", totalWidth));
            sb.AppendLine(new string('*', totalWidth));
            sb.AppendLine();

            // Order Info
            sb.AppendLine($"{"Order ID:",-10}{orderId}");
            sb.AppendLine($"{"Order Date:",-10}{DateTime.Now:yyyy-MM-dd HH:mm}");
            sb.AppendLine($"{"Customer Name:",-10}{customerName}");
            sb.AppendLine($"{"Customer Address:",-10}{customerAddress}");
            if (!string.IsNullOrEmpty(customerPhone))
                sb.AppendLine($"{"Phone No:",-10}{customerPhone}");
            sb.AppendLine($"{"Payment Method:",-10}{paymentMethod}");
            sb.AppendLine();

            // Items Header
            sb.AppendLine(new string('-', totalWidth));
            sb.AppendLine($"{"#".PadRight(colSrNo)} {"Item Name".PadRight(colItem)} {"Qty".PadLeft(colQty)}   {"Rate".PadLeft(colRate)}   {"Total".PadLeft(colTotal)}");
            sb.AppendLine(new string('-', totalWidth));

            // Items Loop
            decimal grandTotal = 0;
            int srNo = 1;
            foreach (var item in items)
            {
                string itemName = item.Item1 ?? string.Empty;
                int quantity = item.Item3;
                decimal unitPrice = item.Item4;
                decimal totalPrice = item.Item5;

                var itemLines = SplitIntoLines(itemName, colItem);

                // First line with all info
                sb.AppendLine(
                    $"{srNo.ToString().PadRight(colSrNo)} {itemLines[0].PadRight(colItem)} {quantity.ToString().PadLeft(colQty)}   {((int)unitPrice).ToString().PadLeft(colRate)}   {((int)totalPrice).ToString().PadLeft(colTotal)}"
                );

                // Additional item name lines
                for (int i = 1; i < itemLines.Count; i++)
                {
                    sb.AppendLine($"   {itemLines[i].PadRight(colItem)}");
                }

                grandTotal += totalPrice;
                srNo++;
            }

            // Totals
            sb.AppendLine(new string('-', totalWidth));
            sb.AppendLine($"{"Subtotal:".PadLeft(totalWidth - 10)} {grandTotal.ToString("F0").PadLeft(5)}");
            if (discount > 0)
                sb.AppendLine($"{"Discount:".PadLeft(totalWidth - 10)} {discount.ToString("F0").PadLeft(5)}");
            sb.AppendLine($"{"GRAND TOTAL:".PadLeft(totalWidth - 10)} {(grandTotal - discount).ToString("F0").PadLeft(5)}");
            sb.AppendLine(new string('-', totalWidth));
            sb.AppendLine();

            // Footer
            sb.AppendLine(CenterText("Thank you for your business!", totalWidth));
            sb.AppendLine(CenterText(DateTime.Now.ToString("dd/MM/yy HH:mm"), totalWidth));
            sb.AppendLine(new string('*', totalWidth));
            sb.AppendLine(CenterText("POWERED BY INVSOL TECHNOLOGIES", totalWidth));
            sb.AppendLine(new string('*', totalWidth));

            return sb.ToString();
        }


        private static List<string> SplitIntoLines(string text, int maxWidth)
        {
            var lines = new List<string>();
            if (string.IsNullOrEmpty(text))
            {
                lines.Add(string.Empty);
                return lines;
            }

            string[] words = text.Split(' ');
            StringBuilder currentLine = new StringBuilder();

            foreach (string word in words)
            {
                if (currentLine.Length + word.Length + 1 <= maxWidth)
                {
                    if (currentLine.Length > 0)
                        currentLine.Append(" ");
                    currentLine.Append(word);
                }
                else
                {
                    if (currentLine.Length == 0)
                    {
                        // Handle long single words
                        lines.Add(word.Substring(0, maxWidth));
                        lines.AddRange(SplitIntoLines(word.Substring(maxWidth), maxWidth));
                    }
                    else
                    {
                        lines.Add(currentLine.ToString());
                        currentLine.Clear();
                        currentLine.Append(word);
                    }
                }
            }

            if (currentLine.Length > 0)
                lines.Add(currentLine.ToString());

            return lines;
        }

        // Helper to center text
        private static string CenterText(string text, int width)
        {
            if (text.Length >= width)
                return text;

            int leftPadding = (width - text.Length) / 2;
            int rightPadding = width - text.Length - leftPadding;
            return new string(' ', leftPadding) + text + new string(' ', rightPadding);
        }

        public static string GenerateThermalInvoiceText(int orderId, string customerName, string customerAddress, string customerPhone, string paymentMethod, decimal discount = 0)
        {
            var items = InvoiceDL.GetInvoiceItems(orderId);
            var sb = new StringBuilder();

            // Constants for 80mm thermal printer (42 characters max width)
            const int thermalWidth = 42;
            const int colItem = 10;
            const int colQty = 5;
            const int colPrice = 8;

            // Header Section (centered)
            sb.AppendLine(CenterText("PIZZA ALBAIK", thermalWidth));
            sb.AppendLine(CenterText("Shop no 4, phase 1", thermalWidth));
            sb.AppendLine(CenterText("Nasheman-e-Iqbal", thermalWidth));
            sb.AppendLine(CenterText("Lahore", thermalWidth));
            sb.AppendLine(CenterText("Ph: 03096081702", thermalWidth));
            sb.AppendLine(new string('=', thermalWidth));

            // Invoice Title
            sb.AppendLine(CenterText("INVOICE", thermalWidth));
            sb.AppendLine(new string('=', thermalWidth));

            // Order Information (compact format)
            sb.AppendLine($"ORD#:{orderId} {DateTime.Now:HH:mm}");
            sb.AppendLine($"CST:{Truncate(customerName, 15)}");
            if (!string.IsNullOrEmpty(customerPhone))
                sb.AppendLine($"PH:{customerPhone}");
            sb.AppendLine($"PAY:{paymentMethod}");
            sb.AppendLine(new string('-', thermalWidth));

            // Items Header
            sb.AppendLine($"{"ITEM".PadRight(colItem)}{"QTY".PadLeft(colQty)}{"PRICE".PadLeft(colPrice)}");
            sb.AppendLine(new string('-', thermalWidth));

            // Items List
            decimal grandTotal = 0;
            foreach (var item in items)
            {
                sb.AppendLine(
                    $"{Truncate(item.Item1, colItem - 3)}" +
                    $"{item.Item3.ToString().PadLeft(colQty)}" +
                    $"{item.Item5.ToString("F2").PadLeft(colPrice)}"
                );
                grandTotal += item.Item5;
            }

            // Totals with discount
            sb.AppendLine(new string('-', thermalWidth));
            sb.AppendLine($"SUBTOTAL:{(grandTotal.ToString("F2")).PadLeft(thermalWidth - 9)}");
            if (discount > 0)
            {
                sb.AppendLine($"DISCOUNT:{discount.ToString("F2").PadLeft(thermalWidth - 8)}");
            }
            sb.AppendLine(new string('=', thermalWidth));
            sb.AppendLine($"TOTAL:{(grandTotal - discount).ToString("F2").PadLeft(thermalWidth - 6)}");
            sb.AppendLine(new string('=', thermalWidth));

            // Footer
            sb.AppendLine(CenterText("Thank you!", thermalWidth));
            sb.AppendLine(CenterText(DateTime.Now.ToString("dd/MM/yy HH:mm"), thermalWidth));
            sb.AppendLine(new string('*', thermalWidth));
            sb.AppendLine(CenterText("INVSOL TECH", thermalWidth));

            // Add paper cut command (ESC m) if supported by printer
            sb.AppendLine("\x1B" + "m");

            return sb.ToString();
        }

        //private static string CenterText(string text, int width)
        //{
        //    if (string.IsNullOrEmpty(text)) return string.Empty;
        //    return text.PadLeft((width + text.Length) / 2).PadRight(width);
        //}
        // Helper method to center text within a given width
        


        private static string Truncate(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty.PadRight(maxLength);
            return value.Length <= maxLength ? value : value.Substring(0, maxLength - 3) + "...";
        }
    }
}