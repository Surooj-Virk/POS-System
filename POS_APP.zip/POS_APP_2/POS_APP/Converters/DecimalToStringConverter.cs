﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace POS_APP.Converters
{
    public class DecimalToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is decimal decimalValue)
            {
                return decimalValue % 1 == 0 ? decimalValue.ToString("F0") : decimalValue.ToString("F2");
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}