﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS_APP.DL
{
    class DBConnection
    {
		public static string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=POS_1;Integrated Security=True;Connect Timeout=30;Encrypt=True;TrustServerCertificate=False;Application Intent=ReadWrite;MultiSubnetFailover=False";
		//public static string connectionString = "Data Source=LAPTOP-152TRFF6;Initial Catalog=POS;Integrated Security=True;Encrypt=False";

	}
}
