﻿using POS_APP.Models;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace POS_APP.DL
{
	public static class StockReconciliationDL
	{
		public static void UpdateSalesForToday(int menuItemId, int quantitySold)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();

				SqlCommand cmd = new SqlCommand(@"
					IF EXISTS (
						SELECT 1 FROM StockReconciliationReport 
						WHERE MenuItemID = @MenuItemID AND Date = CAST(GETDATE() AS DATE)
					)
					BEGIN
						UPDATE StockReconciliationReport
						SET Sales = Sales + @QuantitySold
						WHERE MenuItemID = @MenuItemID AND Date = CAST(GETDATE() AS DATE)
					END
					ELSE
					BEGIN
						INSERT INTO StockReconciliationReport 
						(MenuItemID, OpeningStock, Purchases, Sales, CalculatedClosing, PhysicalStock, Difference, Date)
						VALUES 
						(@MenuItemID, 0, 0, @QuantitySold, 0, 0, 0, CAST(GETDATE() AS DATE))
					END
				", con);

				cmd.Parameters.AddWithValue("@MenuItemID", menuItemId);
				cmd.Parameters.AddWithValue("@QuantitySold", quantitySold);

				cmd.ExecuteNonQuery();
			}
		}

		public static List<ReceivedStockItem> GetItemsWithStockAvailable(DateTime date)
		{
			List<ReceivedStockItem> items = new List<ReceivedStockItem>();

			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				string query = @"
					SELECT mi.MenuItemID, mi.ItemName, mi.Category, mi.Unit, mi.Price, mi.Quantity, mi.Vendor, mi.DateReceived
					FROM MenuItems mi
					JOIN StockReconciliationReport sr ON mi.MenuItemID = sr.MenuItemID
					WHERE sr.Date = @Date AND sr.CalculatedClosing > 0";

				SqlCommand cmd = new SqlCommand(query, con);
				cmd.Parameters.AddWithValue("@Date", date.Date);

				using (SqlDataReader reader = cmd.ExecuteReader())
				{
					while (reader.Read())
					{
						items.Add(new ReceivedStockItem
						{
							MenuItemID = reader.GetInt32(reader.GetOrdinal("MenuItemID")),
							Item = reader["ItemName"]?.ToString(),
							Category = reader["Category"]?.ToString(),
							Unit = reader["Unit"]?.ToString(),
							Price = reader["Price"] != DBNull.Value ? Convert.ToDecimal(reader["Price"]) : 0,
							Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToInt32(reader["Quantity"]) : 0,
							Vendor = reader["Vendor"]?.ToString(),
							Date = reader["DateReceived"] != DBNull.Value ? Convert.ToDateTime(reader["DateReceived"]) : DateTime.MinValue
						});
					}
				}
			}

			return items;
		}
	}
}
