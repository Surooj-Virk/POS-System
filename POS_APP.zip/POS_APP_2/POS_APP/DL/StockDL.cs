﻿using Microsoft.Data.SqlClient;
using System;

namespace POS_APP.DL
{
	public static class StockDL
	{
		// Increase stock quantity for a MenuItemID
		public static bool IncreaseStock(int menuItemId, int quantityToAdd)
		{
			try
			{
				using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
				{
					con.Open();
					string query = @"
                        UPDATE MenuItems
                        SET Quantity = Quantity + @QuantityToAdd
                        WHERE MenuItemID = @MenuItemID";

					using (SqlCommand cmd = new SqlCommand(query, con))
					{
						cmd.Parameters.AddWithValue("@QuantityToAdd", quantityToAdd);
						cmd.Parameters.AddWithValue("@MenuItemID", menuItemId);

						int rows = cmd.ExecuteNonQuery();
						return rows > 0;
					}
				}
			}
			catch (Exception)
			{
				// You can log error here
				return false;
			}
		}
		public static void DecreaseStock(int menuItemId, int quantity)
		{
			using (var con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				var query = "UPDATE MenuItems SET Quantity = Quantity - @qty WHERE MenuItemID = @id";
				using (var cmd = new SqlCommand(query, con))
				{
					cmd.Parameters.AddWithValue("@qty", quantity);
					cmd.Parameters.AddWithValue("@id", menuItemId);
					cmd.ExecuteNonQuery();
				}
			}
		}

		public static void RecordStockTransaction(int menuItemId, int changeInQty, string notes)
		{
			using (var con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				var query = "INSERT INTO StockTransactions (MenuItemID, ChangeInQuantity, Notes) VALUES (@id, @change, @notes)";
				using (var cmd = new SqlCommand(query, con))
				{
					cmd.Parameters.AddWithValue("@id", menuItemId);
					cmd.Parameters.AddWithValue("@change", changeInQty);
					cmd.Parameters.AddWithValue("@notes", notes);
					cmd.ExecuteNonQuery();
				}
			}
		}
		public static bool IsItemPaid(int itemId)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();

				// Adjust this query based on your actual database table/column names
				string query = "SELECT COUNT(*) FROM Purchases WHERE MenuItemID = @itemId AND IsPaid = 1";

				using (SqlCommand cmd = new SqlCommand(query, con))
				{
					cmd.Parameters.AddWithValue("@itemId", itemId);
					int count = (int)cmd.ExecuteScalar();
					return count > 0;
				}
			}
		}

	}
}
