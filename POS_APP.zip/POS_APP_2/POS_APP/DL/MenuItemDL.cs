﻿using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace POS_APP.DL
{
	class MenuItemDL
	{

		//Function to Get All Menu Items

public static List<ReceivedStockItem> GetAllItems()
		{
			List<ReceivedStockItem> items = new List<ReceivedStockItem>();

			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				string query = @"
            SELECT 
                MenuItemID,
                ItemName,
                Category,
                Vendor,
                Unit,
                Quantity,
                Price,
                DateReceived
            FROM MenuItems";

				using (SqlCommand cmd = new SqlCommand(query, con))
				using (SqlDataReader reader = cmd.ExecuteReader())
				{
					while (reader.Read())
					{
						items.Add(new ReceivedStockItem
						{
							MenuItemID = reader.GetInt32(reader.GetOrdinal("MenuItemID")),
							Item = reader["ItemName"]?.ToString(),
							Category = reader["Category"]?.ToString(),
							Vendor = reader["Vendor"]?.ToString(),
							Unit = reader["Unit"]?.ToString(),
							Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToInt32(reader["Quantity"]) : 0,
							Price = reader["Price"] != DBNull.Value ? Convert.ToDecimal(reader["Price"]) : 0,
							Date = reader["DateReceived"] != DBNull.Value ? Convert.ToDateTime(reader["DateReceived"]) : DateTime.MinValue
						});
					}
				}
			}

			return items;
		}


		//ADD ITEMS

		public static void AddItem(ReceivedStockItem item)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("INSERT INTO MenuItems (Name, Price, Category, Quantity) VALUES (@n, @p, @c, @q)", con);
				cmd.Parameters.AddWithValue("@n", item.Item);
				cmd.Parameters.AddWithValue("@p", item.Price);
				cmd.Parameters.AddWithValue("@c", item.Category);
				cmd.Parameters.AddWithValue("@q", item.Quantity);
				cmd.ExecuteNonQuery();
			}
		}

		// UPDATE ITEMS
		public static void UpdateItem(ReceivedStockItem item)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				string query = @"
                    UPDATE MenuItems SET 
                        Vendor = @vendor,
                        Category = @category,
                        Item = @item,
                        Quantity = @quantity,
                        Unit = @unit,
                        Price = @price,
                        DateReceived = @date
                    WHERE ItemCode = @itemCode";

				SqlCommand cmd = new SqlCommand(query, con);
				cmd.Parameters.AddWithValue("@itemCode", (object?)item.ItemCode ?? DBNull.Value);
				cmd.Parameters.AddWithValue("@vendor", (object?)item.Vendor ?? DBNull.Value);
				cmd.Parameters.AddWithValue("@category", (object?)item.Category ?? DBNull.Value);
				cmd.Parameters.AddWithValue("@item", (object?)item.Item ?? DBNull.Value);
				cmd.Parameters.AddWithValue("@quantity", item.Quantity);
				cmd.Parameters.AddWithValue("@unit", (object?)item.Unit ?? DBNull.Value);
				cmd.Parameters.AddWithValue("@price", item.Price);
				cmd.Parameters.AddWithValue("@date", item.Date);

				cmd.ExecuteNonQuery();
			}
		}
		// DELETE ITEMS
		public static void DeleteItem(int id)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("DELETE FROM MenuItems WHERE MenuItemID=@id", con);
				cmd.Parameters.AddWithValue("@id", id);
				cmd.ExecuteNonQuery();
			}
		}
		//Descreasing Quantity
		public static void DecreaseQuantity(int menuItemId, int quantityOrdered)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("UPDATE MenuItems SET Quantity = Quantity - @qty WHERE MenuItemID = @id", con);
				cmd.Parameters.AddWithValue("@qty", quantityOrdered);
				cmd.Parameters.AddWithValue("@id", menuItemId);
				cmd.ExecuteNonQuery();
			}
		}
		public static bool IsDuplicate(string name, string category)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM MenuItems WHERE Name=@n AND Category=@c", con);
				cmd.Parameters.AddWithValue("@n", name);
				cmd.Parameters.AddWithValue("@c", category);
				int count = (int)cmd.ExecuteScalar();
				return count > 0;
			}
		}


	}
}
