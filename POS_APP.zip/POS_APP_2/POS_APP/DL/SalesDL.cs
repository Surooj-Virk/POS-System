﻿using POS_APP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;


namespace POS_APP.DL
{
    class SalesDL
    {
        public static List<SalesReport> GetSalesReport(DateTime from, DateTime to)
        {
            List<SalesReport> report = new List<SalesReport>();

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = @"
SELECT 
    mi.ItemName AS ItemName,
    od.Quantity AS QuantitySold,
    (od.UnitPrice * od.Quantity) AS OriginalAmount,
    (od.UnitPrice * od.Quantity * o.Discount / o.TotalAmount) AS DiscountAmount,
    (od.UnitPrice * od.Quantity) - (od.UnitPrice * od.Quantity * o.Discount / o.TotalAmount) AS FinalAmount,
    o.OrderDate AS Date,
    u.Username AS SoldBy,
    o.PaymentMethod
FROM Orders o
INNER JOIN OrderDetails od ON o.OrderID = od.OrderID
INNER JOIN MenuItems mi ON od.MenuItemID = mi.MenuItemID
INNER JOIN Users u ON o.UserID = u.UserID
WHERE o.OrderDate BETWEEN @from AND @to
ORDER BY o.OrderDate DESC";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to", to);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SalesReport s = new SalesReport(
                        itemName: reader.GetString(0),
                        quantitySold: reader.GetInt32(1),
                        originalAmount: reader.GetDecimal(2),
                        discountAmount: reader.GetDecimal(3),
                        finalAmount: reader.GetDecimal(4),
                        date: reader.GetDateTime(5),
                        soldBy: reader.GetString(6),
                        payment: reader.GetString(7)
                    );

                    report.Add(s);
                }
            }

            return report;
        }


    }
}
