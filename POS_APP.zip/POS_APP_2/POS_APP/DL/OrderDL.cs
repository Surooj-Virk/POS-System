﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using POS_APP.Models;

using System.Windows;
namespace POS_APP.DL
{
    public class OrderDL
    {
        public static List<Tuple<int, string, decimal, string>> GetMenuItems()
        {
            List<Tuple<int, string, decimal, string>> items = new List<Tuple<int, string, decimal, string>>();

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "SELECT MenuItemID, Name, Price, Category FROM MenuItems";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    string name = reader.GetString(1);
                    decimal price = reader.GetDecimal(2);
                    string category = reader.GetString(3);

                    items.Add(Tuple.Create(id, name, price, category));
                }
            }

            return items;
        }
		

		public static bool RecordReturnTransaction(string orderId, int menuItemId, int returnQty, decimal unitPrice)
		{
			try
			{
				using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
				{
					con.Open();
					string query = @"
                INSERT INTO ReturnTransactions (OrderID, MenuItemID, ReturnQuantity, UnitPrice)
                VALUES (@OrderID, @MenuItemID, @ReturnQuantity, @UnitPrice)";

					using (SqlCommand cmd = new SqlCommand(query, con))
					{
						cmd.Parameters.AddWithValue("@OrderID", orderId);
						cmd.Parameters.AddWithValue("@MenuItemID", menuItemId);
						cmd.Parameters.AddWithValue("@ReturnQuantity", returnQty);
						cmd.Parameters.AddWithValue("@UnitPrice", unitPrice);

						int rows = cmd.ExecuteNonQuery();
						return rows > 0;
					}
				}
			}
			catch (Exception)
			{
				// Log error if needed
				return false;
			}
		}

		public static List<OrderItem> GetOrderItemsByOrderId(int orderId)
		{
			var items = new List<OrderItem>();

			try
			{
				using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
				{
					con.Open();

					string query = @"
                        SELECT od.MenuItemID, mi.ItemName, mi.Category, od.Quantity, od.UnitPrice
                        FROM OrderDetails od
                        INNER JOIN MenuItems mi ON od.MenuItemID = mi.MenuItemID
                        WHERE od.OrderID = @OrderID";

					using (SqlCommand cmd = new SqlCommand(query, con))
					{
						cmd.Parameters.AddWithValue("@OrderID", orderId);
						using (var reader = cmd.ExecuteReader())
						{
							while (reader.Read())
							{
								items.Add(new OrderItem
								{
									MenuItemID = reader.GetInt32(0),
									ItemName = reader.GetString(1),
									Category = reader.GetString(2),
									Quantity = reader.GetInt32(3),
									UnitPrice = reader.GetDecimal(4)
								});
							}
						}
					}
				}
			}
			catch (Exception)
			{
				// Log error if needed
				return new List<OrderItem>();
			}

			return items;
		}
		public static void UpdateStockReconciliationAfterSale(int orderId)
		{
			// You need connection string available (replace with your actual)
			string connectionString = DBConnection.connectionString;

			using SqlConnection con = new SqlConnection(connectionString);
			con.Open();

			using SqlTransaction transaction = con.BeginTransaction();

			try
			{
				// Get ordered items and quantities for the order
				string getOrderDetailsSql = @"
            SELECT MenuItemID, Quantity FROM OrderDetails WHERE OrderID = @orderId";

				using SqlCommand cmd = new SqlCommand(getOrderDetailsSql, con, transaction);
				cmd.Parameters.AddWithValue("@orderId", orderId);

				using SqlDataReader reader = cmd.ExecuteReader();

				var orderItems = new List<(int MenuItemID, int Quantity)>();

				while (reader.Read())
				{
					orderItems.Add((reader.GetInt32(0), reader.GetInt32(1)));
				}
				reader.Close();

				DateTime today = DateTime.Today;

				foreach (var item in orderItems)
				{
					int menuItemId = item.MenuItemID;
					int quantitySold = item.Quantity;

					// Get current stock reconciliation record for today if exists
					string selectSql = @"
                SELECT OpeningStock, Purchases, Sales, PurchaseReturns, SalesReturns,
                       DamagedOrExpired, ManualAdjustment, CalculatedClosing, PhysicalStock, Difference
                FROM StockReconciliationReport
                WHERE MenuItemID = @menuItemId AND Date = @date";

					SqlCommand selectCmd = new SqlCommand(selectSql, con, transaction);
					selectCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
					selectCmd.Parameters.AddWithValue("@date", today);

					var existingRecord = selectCmd.ExecuteScalar();

					if (existingRecord == null)
					{
						// No record exists, create a new one

						// Get current stock quantity from MenuItems as opening stock
						string stockSql = "SELECT Quantity FROM MenuItems WHERE MenuItemID = @menuItemId";
						SqlCommand stockCmd = new SqlCommand(stockSql, con, transaction);
						stockCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
						int currentStock = (int)stockCmd.ExecuteScalar();

						int openingStock = currentStock + quantitySold; // Before sale, so add quantitySold back
						int purchases = 0;
						int sales = quantitySold;
						int purchaseReturns = 0;
						int salesReturns = 0;
						int damagedOrExpired = 0;
						int manualAdjustment = 0;

						int calculatedClosing = openingStock - sales + purchaseReturns + salesReturns + damagedOrExpired + manualAdjustment;
						int physicalStock = calculatedClosing; // Assume physical stock equals system calculated
						int difference = physicalStock - calculatedClosing;

						string insertSql = @"
                    INSERT INTO StockReconciliationReport
                    (MenuItemID, OpeningStock, Purchases, Sales, PurchaseReturns, SalesReturns, DamagedOrExpired, ManualAdjustment,
                    CalculatedClosing, PhysicalStock, Difference, Date)
                    VALUES
                    (@menuItemId, @openingStock, @purchases, @sales, @purchaseReturns, @salesReturns, @damagedOrExpired, @manualAdjustment,
                    @calculatedClosing, @physicalStock, @difference, @date)";

						SqlCommand insertCmd = new SqlCommand(insertSql, con, transaction);
						insertCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
						insertCmd.Parameters.AddWithValue("@openingStock", openingStock);
						insertCmd.Parameters.AddWithValue("@purchases", purchases);
						insertCmd.Parameters.AddWithValue("@sales", sales);
						insertCmd.Parameters.AddWithValue("@purchaseReturns", purchaseReturns);
						insertCmd.Parameters.AddWithValue("@salesReturns", salesReturns);
						insertCmd.Parameters.AddWithValue("@damagedOrExpired", damagedOrExpired);
						insertCmd.Parameters.AddWithValue("@manualAdjustment", manualAdjustment);
						insertCmd.Parameters.AddWithValue("@calculatedClosing", calculatedClosing);
						insertCmd.Parameters.AddWithValue("@physicalStock", physicalStock);
						insertCmd.Parameters.AddWithValue("@difference", difference);
						insertCmd.Parameters.AddWithValue("@date", today);

						insertCmd.ExecuteNonQuery();
					}
					else
					{
						// Update existing record: increment Sales and recalc closing, difference
						string updateSql = @"
                    UPDATE StockReconciliationReport
                    SET Sales = Sales + @qtySold,
                        CalculatedClosing = CalculatedClosing - @qtySold,
                        Difference = PhysicalStock - (CalculatedClosing - @qtySold)
                    WHERE MenuItemID = @menuItemId AND Date = @date";

						SqlCommand updateCmd = new SqlCommand(updateSql, con, transaction);
						updateCmd.Parameters.AddWithValue("@qtySold", quantitySold);
						updateCmd.Parameters.AddWithValue("@menuItemId", menuItemId);
						updateCmd.Parameters.AddWithValue("@date", today);

						updateCmd.ExecuteNonQuery();
					}

					// Also reduce quantity in MenuItems table (stock quantity)
					string updateStockSql = @"
                UPDATE MenuItems
                SET Quantity = Quantity - @qtySold
                WHERE MenuItemID = @menuItemId";

					SqlCommand updateStockCmd = new SqlCommand(updateStockSql, con, transaction);
					updateStockCmd.Parameters.AddWithValue("@qtySold", quantitySold);
					updateStockCmd.Parameters.AddWithValue("@menuItemId", menuItemId);

					updateStockCmd.ExecuteNonQuery();
				}

				transaction.Commit();
			}
			catch (Exception ex)
			{
				transaction.Rollback();
				MessageBox.Show($"Failed to update stock reconciliation: {ex.Message}");
			}
		}

		public static int InsertOrder(DateTime orderDate, decimal totalAmount, int userId, string paymentMethod, decimal discount)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				string query = @"INSERT INTO Orders (OrderDate, TotalAmount, UserID, PaymentMethod, Discount, FinalAmount)
                 OUTPUT INSERTED.OrderID
                 VALUES (@date, @total, @user, @method, @discount, @final)";
				SqlCommand cmd = new SqlCommand(query, con);
				cmd.Parameters.AddWithValue("@date", orderDate);
				cmd.Parameters.AddWithValue("@total", totalAmount);
				cmd.Parameters.AddWithValue("@user", userId);
				cmd.Parameters.AddWithValue("@method", paymentMethod);
				cmd.Parameters.AddWithValue("@discount", discount);
				cmd.Parameters.AddWithValue("@final", totalAmount - discount);

				con.Open();
				return (int)cmd.ExecuteScalar();
			}
		}

		public static void InsertOrderDetail(int orderId, int menuItemId, int qty, decimal unitPrice)
		{
			using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
			{
				string query = @"INSERT INTO OrderDetails (OrderID, MenuItemID, Quantity, UnitPrice)
                         VALUES (@oid, @mid, @qty, @price)";
				SqlCommand cmd = new SqlCommand(query, con);
				cmd.Parameters.AddWithValue("@oid", orderId);
				cmd.Parameters.AddWithValue("@mid", menuItemId);
				cmd.Parameters.AddWithValue("@qty", qty);
				cmd.Parameters.AddWithValue("@price", unitPrice);

				con.Open();
				cmd.ExecuteNonQuery();
			}

			MenuItemDL.DecreaseQuantity(menuItemId, qty);
		}
		public static void AddPurchaseToStockReconciliation(int menuItemId, int quantityAdded)
		{

			try
			{

				using SqlConnection con = new SqlConnection(DBConnection.connectionString);
				con.Open();

				using SqlTransaction transaction = con.BeginTransaction();

				// Get previous day's closing stock
				string getPrevClosingQuery = @"
			SELECT TOP 1 CalculatedClosing 
			FROM StockReconciliationReport 
			WHERE MenuItemID = @menuItemId AND Date < CAST(GETDATE() AS DATE)
			ORDER BY Date DESC";

				int openingStock = 0;
				using (SqlCommand cmdPrev = new SqlCommand(getPrevClosingQuery, con, transaction))
				{
					cmdPrev.Parameters.AddWithValue("@menuItemId", menuItemId);
					object result = cmdPrev.ExecuteScalar();
					if (result != null && int.TryParse(result.ToString(), out int prevClosing))
					{
						openingStock = prevClosing;
					}
				}

				string query = @"
		IF EXISTS (
			SELECT 1 FROM StockReconciliationReport 
			WHERE MenuItemID = @menuItemId AND Date = CAST(GETDATE() AS DATE)
		)
		BEGIN
			UPDATE StockReconciliationReport
			SET Purchases = Purchases + @quantityAdded,
				CalculatedClosing = CalculatedClosing + @quantityAdded
			WHERE MenuItemID = @menuItemId AND Date = CAST(GETDATE() AS DATE)
		END
		ELSE
		BEGIN
			INSERT INTO StockReconciliationReport
				(MenuItemID, OpeningStock, Purchases, Sales, PurchaseReturns, SalesReturns, DamagedOrExpired, ManualAdjustment, CalculatedClosing, PhysicalStock, Difference, Date)
			VALUES
				(@menuItemId, @openingStock, @quantityAdded, 0, 0, 0, 0, 0, @calculatedClosing, 0, 0, CAST(GETDATE() AS DATE))
		END";

				using SqlCommand cmd = new SqlCommand(query, con, transaction);
				cmd.Parameters.AddWithValue("@menuItemId", menuItemId);
				cmd.Parameters.AddWithValue("@quantityAdded", quantityAdded);
				cmd.Parameters.AddWithValue("@openingStock", openingStock);
				cmd.Parameters.AddWithValue("@calculatedClosing", openingStock + quantityAdded);

				cmd.ExecuteNonQuery();

				transaction.Commit();
			}
			catch (Exception ex)
			{
				// Handle exceptions/logging as needed
				throw new ApplicationException("Error updating stock reconciliation", ex);
			}
		}

		public static void UpdateStockReconciliationQuantity(int menuItemId, int quantityChange, SqlTransaction transaction)
		{
			using SqlCommand cmd = new SqlCommand(@"
		IF EXISTS (SELECT 1 FROM StockReconciliationReport WHERE MenuItemID = @menuItemId AND Date = CAST(GETDATE() AS DATE))
		BEGIN
			UPDATE StockReconciliationReport
			SET Purchases = Purchases + @quantityChange,
				CalculatedClosing = CalculatedClosing + @quantityChange
			WHERE MenuItemID = @menuItemId AND Date = CAST(GETDATE() AS DATE)
		END
		ELSE
		BEGIN
			INSERT INTO StockReconciliationReport
				(MenuItemID, OpeningStock, Purchases, Sales, CalculatedClosing, PhysicalStock, Difference, Date)
			VALUES
				(@menuItemId, 0, @quantityChange, 0, @quantityChange, 0, 0, CAST(GETDATE() AS DATE))
		END
	", transaction.Connection, transaction);

			cmd.Parameters.AddWithValue("@menuItemId", menuItemId);
			cmd.Parameters.AddWithValue("@quantityChange", quantityChange);

			cmd.ExecuteNonQuery();
		}


		public static bool UserExists(int userId)
        {
            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                string query = "SELECT COUNT(*) FROM Users WHERE UserID = @userId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@userId", userId);

                con.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }
    }
}
