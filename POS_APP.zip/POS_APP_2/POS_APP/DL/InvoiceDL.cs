﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace POS_APP.DL
{
    class InvoiceDL
    {
        public static List<Tuple<string, string, int, decimal, decimal>> GetInvoiceItems(int orderId)
        {
            List<Tuple<string, string, int, decimal, decimal>> list = new List<Tuple<string, string, int, decimal, decimal>>();
            if (orderId <= 0)
            {
                return list; 
            }
            string query = @"
                SELECT 
                    mi.ItemName,
                    mi.Category,
                    od.Quantity,
                    od.UnitPrice,
                    (od.UnitPrice * od.Quantity) AS Total
                FROM OrderDetails od
                JOIN MenuItems mi ON od.MenuItemID = mi.MenuItemID
                WHERE od.OrderID = @orderId";

            using (SqlConnection con = new SqlConnection(DBConnection.connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@orderId", orderId);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Tuple<string, string, int, decimal, decimal>(
                        reader.GetString(0),     
                        reader.GetString(1),     
                        reader.GetInt32(2),      
                        reader.GetDecimal(3),    
                        reader.GetDecimal(4)   
                    ));
                }
            }
            return list;

        }



    }
}

